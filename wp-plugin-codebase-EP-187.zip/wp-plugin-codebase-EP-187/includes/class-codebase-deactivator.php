<?php
/**
 * Fired during plugin deactivation
 *
 * @link       https://takamoastudio.com/
 * @since      0.0.0
 *
 * @package    Codebase
 * @subpackage Codebase/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      0.0.0
 * @package    Codebase
 * @subpackage Codebase/includes
 * @author     Takamoa Studio <responsable@takamoastudio.com>
 */
class Codebase_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    0.0.0
	 */
	public static function deactivate() {
		var_dump('deactivate');
		
	}

}
?>