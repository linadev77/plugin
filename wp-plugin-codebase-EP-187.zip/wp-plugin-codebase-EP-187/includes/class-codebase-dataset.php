<?php
/**
 * Fired during plugin activation
 *
 * @link       https://takamoastudio.com/
 * @since      0.0.0
 *
 * @package    Codebase
 * @subpackage Wp-plugin-codebase/includes
 */

/**
 * Fired during plugin activation. https://regex101.com/r/TvKR9I/1
 *
 * This class defines all code necessary to run during the plugin"s activation.
 *
 * @since      0.0.0
 * @package    Codebase
 * @subpackage wp-plugin-codebase/includes
 * @author     Takamoa Studio <responsable@takamoastudio.com>
 */
class Codebase_Dataset {
    
}