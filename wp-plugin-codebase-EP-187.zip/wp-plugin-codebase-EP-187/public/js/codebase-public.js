jQuery(document).ready(function ($) {
    $(".bloc_value_attribut").click(function(){
        var paragraphe = $(this).find("p");
          var attribute = $(this).data("attribut");
        var valeurAtribute = paragraphe.text();
        $('.attribut_label_' + attribute).text(valeurAtribute);
    });

    $(".select_exemplaire").on("change", function() {
        var selectedValue = $(this).val();
        $(".value_exemplaire").text(selectedValue);

    });    
    
    $(".select_dimension").on("change", function() {
        var selectedValue = $(this).val();
        $(".value_dimensions").text(selectedValue);

    });

    $(".autres_specifications").on("input", function() {
        var valeurTextarea = $(this).val();
        $(".value_specification").text(valeurTextarea);
    });
    
    // Récupération du nom de fichier lorsque le champ de fichier est sélectionné
    $("#myfile").on("change", function() {
        var fileName = $(this).val().split("\\").pop();
        alert("Le fichier sélectionné est : " + fileName);
    });

});