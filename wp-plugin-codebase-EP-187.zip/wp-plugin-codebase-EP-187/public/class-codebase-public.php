<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://takamoastudio.com/
 * @since      0.0.0
 *
 * @package    Codebase
 * @subpackage Wp-plugni-codebase/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Codebase
 * @subpackage Wp-plugin-codebase/public
 * @author     Takamoa Studio <responsable@takamoastudio.com>
 */
class Codebase_Public {
	/**
	 * The ID of this plugin.
	 *
	 * @since    0.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    0.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;	

	private $dataset;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    0.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */	
	public function __construct( $plugin_name, $version, $dataset ) {
		require_once ABSPATH . 'wp-admin/includes/image.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';

		$this->plugin_name = $plugin_name;
		$this->version = $version;
		$this->dataset = $dataset;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    0.0.0
	 */	
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Codebase_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Codebase_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/codebase-public.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    0.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Codebase_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Codebase_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/codebase-public.js', array( 'jquery' ), $this->version, false );

		
	}	

	function afficher_variations_produit_variable() {
		global $product;
	
		if ($product->is_type('variable')) {
			$attributes = $product->get_attributes();
	
			if ($attributes) {
				?>
				<div class="variation-attributes">
					<!-- ATTIBUTS DU PRODUITS -->
					<div class="bloc-variation">
						<h2>Attributs du produit:</h2>
						<table class="table_variation">
							<tbody>
								<?php foreach ($attributes as $attribute) : ?>
									<?php
									$attribute_label = wc_attribute_label($attribute->get_name());
									$attribute_values = $attribute->get_options();
	
									if (!empty($attribute_values)) :
										?>
										<tr>
											<th class="label">
												<label for="<?php echo sanitize_title($attribute_label); ?>"><?php echo $attribute_label; ?> :</label>
											</th>
											<td class="value">
												<div class="produit_attribut_variable">
													<?php foreach ($attribute_values as $value) : ?>
														<?php
														$image_url = plugin_dir_url(dirname(__FILE__)) . 'public/images/' . sanitize_title($value) . '.png';
														$variations = $product->get_available_variations();
														foreach ($variations as $variation) {
															$variation_id = $variation['variation_id'];
															$variation_price = wc_get_product($variation_id)->get_price();
	
															if ($value === $variation['attributes']['attribute_' . sanitize_title($attribute_label)]) :
																?>
																<div id="<?php echo sanitize_title($value); ?>" class="<?php echo sanitize_title($value); ?> bloc_value_attribut" data-attribut="<?php echo sanitize_title($attribute_label); ?>">
																	<div id="<?php echo sanitize_title($value).'_'.sanitize_title($attribute_label); ?>" class="attribut_label <?php echo sanitize_title($value); ?>">
																		<img src="<?php echo $image_url; ?>" alt="<?php echo $value; ?>.png">
																		<p><?php echo $value; ?></p>
																		<p class="variation-price">Prix : <?php echo wc_price($variation_price); ?></p>
																	</div>
																</div>
																<?php
																break; // Sortir de la boucle des variations après avoir trouvé la correspondance.
															endif;
														}
														?>
													<?php endforeach; ?>
												</div>
											</td>
										</tr>
									<?php endif; ?>
								<?php endforeach; ?>
								<tr>
									<th>
										<label for="select_dimension">Dimensions: </label>
									</th>
									<td>
										<div class="bloc_dimension_homestore">
											<select name="select_dimension" id="select_dimension" class="select_dimension">
												<?php $variations = $product->get_available_variations();?>
												<?php foreach ($variations as $variation) : ?>
													<?php
													$dimensions_html = $variation['dimensions_html'];
													?>
													<option value="<?php echo esc_attr($dimensions_html); ?>"><?php echo esc_html($dimensions_html); ?></option>
												<?php endforeach; ?>
											</select>
										</div>
									</td>
								</tr>
							
								<tr>
									<th>
										<label for="nbr_exemplaire_homestore">Nombre d'exemplaires: </label>
									</th>
									<td>
										<div class="bloc_exemplaire_homestore">
											<select name="select_exemplaire" class="select_exemplaire">
												<option value="1">1</option>
												<option value="2">2</option>
											</select>
										</div>
									</td>
								</tr>

								<tr>
									<th>
										<label for="autres_specifications_homestore">Autres spécifications: </label>
									</th>
									<td>
										<div class="specification_homestore">
											<textarea name="autres_specifications" id="autres_specifications" class="autres_specifications" rows="10" style="width:100%">
												Votre demande spécifique
											</textarea>
										</div>
									</td>
								</tr>									
							</tbody>
						</table>
						<div class="specification_homestore" style="width:100%">
							<input type="file" id="myfile" name="myfile">
						</div>
					</div>
					<!-- RECAPITULATIF (VARIATION) -->

					<div id="variation_recap">
							<div class="recap-container" style="display: flex;background: #FAFAFA;padding: 20px;transition: all .2s linear;width: 400px;">
								<div class="order-recap" style="width: 400px;display: flex;flex-direction: column;justify-content: center;">
									<div class="head">Récapitulatif de votre commande</div>
									
									<?php
										// Récupérer l'ID du produit
										$product_id = get_the_ID();
										
										// Récupérer les attributs du produit
										$product_attributes = wc_get_product($product_id)->get_attributes();
										
										// Parcourir les attributs et afficher les valeurs
										foreach ($product_attributes as $attribute_name => $attribute) {
											$attribute_value = wc_get_product($product_id)->get_attribute($attribute_name);//rouge,gris,marron											
											$attribute_values = explode('|', $attribute_value);
											$first_value = trim($attribute_values[0]);
											
											
											if (!empty($attribute_value)) {
										?>
										<div class="order-recap-item">
											<div class="<?php echo 'item_'.wc_attribute_label($attribute_name);?>"><?=wc_attribute_label($attribute_name);?></div>
											<div class="item_value_color <?php echo 'attribut_label_' . sanitize_title(wc_attribute_label($attribute_name)); ?>"><?=$first_value?></div>
										</div>											
										<?php
											}
										}
									?>
										<div class="order-recap-item">
											<div class="title">Dimensions : </div>
											<div class="value_dimensions">dimensions</div>
										</div>									
										<div class="order-recap-item">
											<div class="title">Exemplaires : </div>
											<div class="value_exemplaire">3 exemplaires</div>
										</div>
										<div class="order-recap-item">
											<div class="title">Specification : </div>
											<div class="value_specification">Sans</div>
										</div>
										<div class="order-recap-item">
											<div class="title">Prix: </div>
											<div class="value">43,27€</div>
										</div>
										<div class="order-recap-item">
											<div class="title">TVA</div>
											<div class="value">8.65€</div>
										</div>
										<hr style="border-color: rgb(151, 131, 103); margin: 3px 0px;">
										<div class="order-recap-item total">
											<div class="title">TOTAL TTC</div>
											<div class="value">26.53 €</div>
										</div>
										<?php $id = get_the_ID();?>
										<button type="submit" name="add-to-cart" class="single_add_to_cart_button" value="<?php echo $id; ?>" style="color:#FFF,background: #006FB7; cursor: not-allowed;border:none;">
											Terminer
										</button>									
									
								</div>								
							</div>
					</div>
						<!-- FIN VARIATION -->
				</div>							
				<?php
			}
		}
	}
	













	

}