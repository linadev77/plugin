<div class="container">
    <div class="row">
        <h2>PRODUITS ETAPES PRINT</h2>
        <form method="post" name="form_pep">
            <label for="cle_activation">Clé d'activation</label>
            <input type="text" name="cle_activation" class="cle_activation"/>
            <input type="submit" value="Submit" name="submit_cle_activation"/>
            <div class="alert_msg"><?php echo $erreur;?></div>
        </form>
        
    </div>
</div>

