<div class="container">
    <div class="wrap">
        <div class="pageFactureAchat">
            <form class="form_download">                
                    <div class="blocs_download_rib">
                        <label for="myfile" class="label_download_rib"><i class="dashicons dashicons-download"></i>Télécharger le RIB d'ETAPES PRINT</label>
                        <input type="file" id="myfile" name="myfile" style="display:none;"><br><br>                
                    </div>                                  
            </form>

            <form class="form_relever">
                <h2>relevé de factures depuis 07/2013</h2>
                <div class="blocs_factures">
                    <div class="bloc_select_facture">
                        <label for="select_facture"></label>                        
                            <select name="select_facture" class="select_facture" style="border: none;box-shadow: 0px 3px 0px 0px #868695;border-radius: 0px;background-color:#f0f0f1;font-weight: bold;color:#8c8f94">
                                <option value="">Novembre 2022</option>
                            </select>                                                     
                    </div>
                    <div class="blocs_select_relever">
                        <div>
                            <select name="select_relever" class="select_relever">
                                <option value="">Télécharger le relevé</option>
                            </select>                    
                        </div>                    
                        <div>                       
                            <label for="myfile" class="label_download_fact_mois">Télécharger les fact du mois</label>
                            <input type="file" id="myfile" name="myfile" style="display:none;"><br><br>                
                        </div>
                    </div>
                </div>             
            </form>        
        </div>
    </div>
</div>

