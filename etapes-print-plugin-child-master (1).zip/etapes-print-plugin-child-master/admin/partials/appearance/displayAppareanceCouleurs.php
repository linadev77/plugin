<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       x
 * @since      2.0.5
 *
 * @package    Etapes_Print
 * @subpackage Etapes_Print/admin/partials
 */

defined('ABSPATH') || exit;

// Usage:
$button_settings = [
    'border-image-color' => 'border: 1px solid',
    'button-color' => 'color',
    'button-bg' => 'background-color',
    'button-border' => 'border-color',
];
$button_hover_settings = [
    'button-hover-color' => 'color: %s;',
    'button-hover-bg' => 'background-color: %s;',
    'button-hover-border' => 'border-color: %s;',
];

?>
<!-- Apparence des pages produits -->
<?php if (isset($_GET['uploaded']) || (isset($_GET['deleted']))) { ?>
    <div class="notice updated notice-sucess is-dismissible">
        <p><?php echo $_GET['uploaded'] ? 'Enregistrement d\'une image avec succes' : 'Suppression d\'une image avec succes'; ?></p>
    </div>
<?php } ?>
<div class="wrap app-charte-graphique app-charte-color">
    <div class="app-gestion">
        <div>
            <h2>Gestionnaire d’icônes des pages produits</h2>
            <p>Vous pouvez configurer l'apparence générale de vos pages produits</p>
        </div>
        <div class="app-conserver">
            <div class="app-btn-conserver app-btn-kepp">
                <h3><span class="dashicons dashicons-yes-alt"></span> Prédefinir vos palettes de couleurs</h3>
                <p>
                    En sélectionnant les icônes prédéfinis, les visuels seront imposés. Vous ne pourrez pas les personnaliser.
                </p>
            </div>
            <div class="app-btn-conserver app-btn-custom active">
                <h3><span class="dashicons dashicons-yes-alt"></span> Customiser vos palettes de couleurs</h3>
                <p>
                    Merci de télécharger un par un vos icônes au format SVG, PNG ou JPEG. La taille maximale d'un icône ne peut pas excéder 150 x 150 pixels
                </p>
            </div>
        </div>
        <div class="app-predifined-icones app-tab-pane"></div>
        <div class="app-tab-pane active">
            <form action="" method="post">
                <div class="d-flex">
                    <div class="w-30 mt-3">
                        <table>
                            <thead>
                                <tr>
                                    <th class="pb-1">Choisir la couleur</th>
                                    <th><a href="">Effacer tout</a></th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Border Image color</td>
                                    <td>
                                        <div class="input-color-container m-0">
                                            <input id="border-image-color" name="border-image-color" class="input-color" value="<?php echo (get_option('border-image-color') ? get_option('border-image-color') : '#f061217a'); ?>" type="color">
                                            <span class="dashicons dashicons-arrow-right-alt2"></span>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Border Image color Hover</td>
                                    <td>
                                        <div class="input-color-container m-0">
                                            <input id="border-image-color-hover" name="border-image-color-hover" class="input-color" value="<?php echo (get_option('border-image-color-hover') ? get_option('border-image-color-hover') : '#f06121'); ?>" type="color">
                                            <span class="dashicons dashicons-arrow-right-alt2"></span>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Button color</td>
                                    <td>
                                        <div class="input-color-container m-0">
                                            <input id="boutton-color" name="button-color" class="input-color" value="<?php echo (get_option('button-color') ? get_option('button-color') : '#ffffff'); ?>"  type="color">
                                            <span class="dashicons dashicons-arrow-right-alt2"></span>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Button Background</td>
                                    <td>
                                        <div class="input-color-container m-0">
                                            <input id="boutton-bg" name="button-bg" class="input-color" value="<?php echo (get_option('button-bg') ? get_option('button-bg') : '#f06121'); ?>"  type="color">
                                            <span class="dashicons dashicons-arrow-right-alt2"></span>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Button Border</td>
                                    <td>
                                        <div class="input-color-container m-0">
                                            <input id="boutton-border" name="button-border" class="input-color" value="<?php echo (get_option('button-border') ? get_option('button-border') : '#000000'); ?>" type="color">
                                            <span class="dashicons dashicons-arrow-right-alt2"></span>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Button Hover Text</td>
                                    <td>
                                        <div class="input-color-container m-0">
                                            <input id="boutton-hover-color" name="button-hover-color" class="input-color" value="<?php echo (get_option('button-hover-color') ? get_option('button-hover-color') : '#000000'); ?>" type="color">
                                            <span class="dashicons dashicons-arrow-right-alt2"></span>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Button Hover Background</td>
                                    <td>
                                        <div class="input-color-container m-0">
                                            <input id="boutton-hover-bg" name="button-hover-bg" class="input-color"  value="<?php echo (get_option('button-hover-bg') ? get_option('button-hover-bg') : '#f0612178'); ?>" type="color">
                                            <span class="dashicons dashicons-arrow-right-alt2"></span>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Button Hover Border</td>
                                    <td>
                                        <div class="input-color-container m-0">
                                            <input id="boutton-hover-border" name="button-hover-border" class="input-color" value="<?php echo (get_option('button-hover-border') ? get_option('button-hover-border') : '#000000'); ?>" type="color">
                                            <span class="dashicons dashicons-arrow-right-alt2"></span>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="w-50 mt57px">
                        <h4 class="m-0">Prévisualiser</h4>
                        <div class="d-flex mt-1">
                            <div class="image-placeholder imp-1">
                                <span class="dashicons dashicons-format-image"></span>
                            </div>
                            <div class="w-50 imp-2 ml-1">
                                <h4>Product Title</h4>
                                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Mollitia vero,
                                    quo quis vel maxime eos accusantium deleniti nam dolorem pariatur.
                                </p>
                                <h5>Sélectionnez votre Papier :</h5>
                                <div class="imp-option d-flex">
                                    <div id="border-color-img" class="image-placeholder" style="<?php echo (get_option('border-image-color') ? 'border: 1px solid ' . get_option('border-image-color') . ';' : ''); ?>" >
                                        <span class="dashicons dashicons-format-image"></span>
                                    </div>
                                    <div class="image-placeholder" style="<?php echo (get_option('border-image-color-hover') ? 'border: 1px solid ' . get_option('border-image-color-hover') . ';' : ''); ?>">
                                        <span class="dashicons dashicons-format-image"></span>
                                    </div>
                                </div>
                                <div class="button_custom">
                                    <button type="button" id="button_custom_bg" style="<?php echo $this->dataset->get_button_styles($button_settings, ''); ?>">Button</button>
                                    <button type="button" id="button_custom_bg_hover" style="<?php echo $this->dataset->get_button_styles('',$button_hover_settings); ?>">Button Hover</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="flex-right">
                    <input class="button button-primary button-large button-app-register" type="submit" value="Sauvergarder" name="register-colors">
                </div>
            </form>
        </div>
    </div>
</div>