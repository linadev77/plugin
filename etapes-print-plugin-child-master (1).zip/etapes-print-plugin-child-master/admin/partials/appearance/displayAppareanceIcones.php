<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       x
 * @since      2.0.5
 *
 * @package    Etapes_Print
 * @subpackage Etapes_Print/admin/partials
 */

defined('ABSPATH') || exit;

?>
<!-- Apparence des pages produits -->
<?php if(isset($_GET['uploaded']) || (isset($_GET['deleted']) )) { ?>
<div class="notice updated notice-sucess is-dismissible">
    <p><?php echo $_GET['uploaded'] ? 'Enregistrement d\'une image avec succes':'Suppression d\'une image avec succes' ; ?></p>
</div>
<?php } ?>
<div class="wrap app-charte-graphique">
    <div class="app-gestion">
        <div>
            <h2>Gestionnaire d’icônes des pages produits</h2>
            <p>Vous pouvez configurer l'apparence générale de vos pages produits</p>
        </div>
        <div class="app-conserver">
            <div class="app-btn-conserver app-btn-kepp">
                <h3><span class="dashicons dashicons-yes-alt"></span> Conserver les icônes pré-définis</h3>
                <p>
                    En sélectionnant les icônes prédéfinis, les visuels seront imposés. Vous ne pourrez pas les personnaliser.
                </p>
            </div>
            <div class="app-btn-conserver app-btn-custom active">
                <h3><span class="dashicons dashicons-yes-alt"></span> Customiser vos icônes</h3>
                <p>
                    Merci de télécharger un par un vos icônes au format SVG, PNG ou JPEG. La taille maximale d'un icône ne peut pas excéder 150 x 150 pixels
                </p>
            </div>
        </div>
        <div class="app-predifined-icones app-tab-pane"></div>
        <div class="app-tab-pane active">
            <div class="app-btn-recherche m-0">
                <div class="app-btn-recherhe-flex">
                    <div class="m-0 app-issearch d-flex">
                        <form action="<?php echo get_permalink() ?>" method="get">
                            <input type="hidden" name="page" value="<?php echo $page ?>">
                            <input type="hidden" name="gestionnaire" value="icones">
                            <input type="text" name="search-code" placeholder="Recherher une image..." value="<?= isset($_GET['search-code']) ? $_GET['search-code'] : '' ?>">
                            <button type="submit">Rechercher</button>
                        </form>
                        <?php if(isset($_GET['search-code'])) { if($_GET['search-code'] != ''){ ?>
                            <a class="app-see-all" href="<?php echo admin_url( "admin.php?page=$page&gestionnaire=icones" ); ?>" class="btn btn-primary">Voir tous</a> 
                        <?php } } ?>
                        </div>
                    <div class="app-choose-file">
                        <button>Ajouter une image...</button>
                    </div>
                </div>
            </div>
            <div class="app-customize-icones">
                <?php  foreach ($results as $key => $value) { ?>
                <div class="app-column-icon">
                    <a class="dashicons dashicons-no" href="?page=<?php echo $page ?>&gestionnaire=icones&delete=<?php echo $value['id'] ?>"></a>
                    <img src="<?php  echo site_url('wp-content/uploads').'/etapes-print/'.$value['url'] ?>" alt="">
                    <h4><?php echo $value['code'] ?></h4>
                </div>
                <?php } ?>
                <?php if(sizeof($results) == 0) {
                    if (isset($_GET['search-code'])) { ?>
                        <p class="app-not-found">Pas de résultats pour <b><u><?= $_GET['search-code'] ?></u><b> !</p>
                    <?php } else { ?>
                        <p class="app-not-found">Aucunes images ajoutées</p>
                <?php } } ?>
            </div>
        </div>
    </div>

    <!-- modal -->
    <div class="app-modal">
        <div class="app-modal-content">
            <form action="" method="post" enctype="multipart/form-data">
                <div>
                    <label for=""><b>Selectionner l'option</b></label>
                    <select name="" id="select_option" required> 
                        <?php foreach ($options as $key => $value) {  ?>     
                            <option value="<?php echo $value ?>"><?php echo $value ?></option>
                        <?php } ?>
                    </select>
                </div>
                <div>
                    <label for=""><b>Selectionner le code</b></label>
                    <select name="code" id="code_option" required>
                        <option value="">-- Code</option>
                    </select>
                </div>
                <div class="app-choose-file">
                    <input type="file" name="url" id="upload" accept="image/svg+xml,image/png,image/jpeg" hidden required/>
                    <label for="upload" class="label-upload"><span class="dashicons dashicons-upload"></span>Ajouter une image...</label>
                    <p class="app-message">* Les fichiers autorisés sont : png - jpeg - svg </p>
                </div>
                <div class="app-action-modal m-0">
                    <button type="button" class="app-close-modal">Annuler</button>
                    <input type="submit" value="Enregistrer" name="register">
                </div>
            </form>
        </div>
    </div>
    <!-- End modal -->

</div>