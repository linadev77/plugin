<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       x
 * @since      2.0.5
 *
 * @package    Etapes_Print
 * @subpackage Etapes_Print/admin/partials
 */

defined('ABSPATH') || exit;
?>

<!-- Apparence des pages produits -->
<div class="wrap app-charte-graphique">
    <div>
        <h2>Apparence des pages produits</h2>
        <p>Vous pouvez configurer l'apparence générale de vos pages produits</p>
    </div>
    <div class="app-gestion">
        <div class="mb-4">
            <a href="<?php echo admin_url( "admin.php?page=$page&gestionnaire=couleurs" ); ?>">
                <span>Gestionnaire de couleurs des pages produits</span>
                <span>Sélectionner une palette de couleurs pour vos pages produits</span>
            </a>
        </div>
        <div>
            <a href="<?php echo admin_url( "admin.php?page=$page&gestionnaire=icones" ); ?>">
                <span>Gestionnaire d’icônes des pages produits</span>
                <span>Sélectionner les icônes de vos pages produits</span>
            </a>
        </div>
    </div>
</div>