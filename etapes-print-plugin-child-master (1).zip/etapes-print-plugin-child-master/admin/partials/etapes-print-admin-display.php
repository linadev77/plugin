<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       x
 * @since      2.0.5
 *
 * @package    Etapes_Print
 * @subpackage Etapes_Print/admin/partials
 */

defined('ABSPATH') || exit;
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<div class="wrap wrap_info_marketplace">
  <h1>Information Marketplace</h1>
  <div class="info_marketplace">
    <form action="" method="post">
      <h2>Clé API</h2>
      <input required type="text" class="etapes_print_input api_key" name="api_key" value="<?php echo get_option('etapes_print_api_key') ?>" />
      <button class="button button-primary button-large" type="submit" name="etapes_print_api_key_submit" value="ok">Mettre à jour la clé API</button>
    </form>
    <table class="form-table form-table-infos">
      <tbody>
        <?php foreach ($etapes_print_markeplace as $key => $value) { ?>
          <tr>
            <th><label for="<?php echo $key ?>"><?php echo $value ?></label></th>
            <td><span><?php echo get_option('etapes_print_' . $key, 'N/A') ?></span></td>
          </tr>
        <?php } ?>
      </tbody>
    </table>
  </div>
  <br />
  <h1>Paramètre d'affichage globale</h1>
  <form action="" method="post">
    <div class="info_marketplace">
    <h2>Marge bénéficiaire par défaut</h2>
      <div>
        <input required type="number" class="etapes_print_marge_default_value" name="etapes_print_marge_default_value"  value="<?php echo get_option('etapes_print_marge_default_value') ?>" />
        <select name="etapes_print_unit_measure" id="">
          <?php foreach (['%','€'] as $value) { ?>
            <option value="<?php echo $value ?>" <?php echo (get_option('etapes_print_unit_measure') == $value ? 'selected="selected"' : '') ?>><?php echo $value ?></option>
          <?php } ?>
        </select>
      </div>
      <h2>Sélectionner les options à afficher en liste d'images :</h2>
      <select style="width: 100%; min-height: 168px;" name="customized_option[]" multiple="multiple">
        <?php foreach ($etape_print_options as $value) { ?>
          <option value="<?php echo $value ?>" <?php echo (str_contains($customised_options, $value) ? 'selected="selected"' : '') ?>><?php echo $this->dataset->get_label_by_key($value) ?></option>
        <?php } ?>
      </select>
      <h2>Afficher les sous-options sous forme de liste au-delà de :</h2>
      <div>
        <input required type="number" class="etapes_print_input custom_display_limit" name="custom_display_limit" value="<?php echo get_option('etapes_print_custom_display_limit') ?>" />
        <span>éléments</span>
      </div>
    </div>
    <button class="button button-primary button-large" style="margin-top:3em;" type="submit" name="etapes_print_submit" value="ok">Enregistrer</button>
  </form>
</div>
