<?php
/**
 * The admin-specific functionality of the plugin.
 *
 * @link       x
 * @since      2.0.5
 *
 * @package    Etapes_Print
 * @subpackage Etapes_Print/admin
 */

 /**
  * The admin-specific functionality of the plugin.
  *
  * Defines the plugin name, version, and two examples hooks for how to
  * enqueue the admin-specific stylesheet and JavaScript.
  *
  * @package    Etapes_Print
  * @subpackage Etapes_Print/admin/modules
  * @author     Njakasoa Rasolohery <ras.njaka@gmail.com>
  */
class WC_Product_Etapes_Print extends WC_Product {
    public function __construct( $product ) {
        $this->product_type = 'etapes_print';
        parent::__construct( $product );
    }
}