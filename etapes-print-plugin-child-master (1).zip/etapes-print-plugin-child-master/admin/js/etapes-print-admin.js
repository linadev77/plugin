(function( $ ) {
	'use strict';

	/**
	 * All of the code for your admin-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */

	$(function() {
		$("select#etapes_print_select_multiple").each(function (index) {
			const select = $(this);
			select.change(() => {
				const selectedOptions = select.children("option:selected");
				const classId = select.attr('name').replace('values[]', 'default_value');
				const targetSelect = $(`select#${classId}`).first();
				let defaultValue = targetSelect.children("option:selected").val();
				targetSelect.empty();
				selectedOptions.each(function (index) {
					const option  = $(this).clone();
					if (defaultValue !== option.val()) {
						option.removeAttr("selected");
					}
					targetSelect.append(option);
				});
			});
			select.trigger("change");
		});

		$('#etapes_print_client_category').change(function(){
			const categoryEl = $('#etapes_print_client_category');
			categoryEl.attr('disabled', 'disabled');
			const categoryId = $('#etapes_print_client_category option:selected').val();
			const currentUrl = new URL(window.location.href);
			currentUrl.searchParams.set("ep_category_id", categoryId);
			window.history.pushState({}, "", currentUrl.href);
			const url = etapes_print_js_object['etapes_print_server_url'];
			if (url) {
				$.get(`${url}/wp-json/etapes-print/api/categories/${currentUrl.searchParams.get("ep_category_id")}/products`, function(products, status){
					categoryEl.removeAttr('disabled');
					// clear all option first
					const productEl = $('#etapes_print_client_product');
					productEl.empty();
					// populate options
					products.forEach(product => {
						productEl.append(`<option value="${product['id']}">${product['name']}</option>`);
					});
				})
			}
		});

		$('#etapes_print_client_product').change(function(){
			const productId = $('#etapes_print_client_product option:selected').val();
			let currentUrl = new URL(window.location.href);
			currentUrl.searchParams.set("ep_product_id", productId);
			window.history.pushState({}, "", currentUrl.href);
			const url = etapes_print_js_object['etapes_print_server_url'];
			const apiKey = etapes_print_js_object['etapes_print_api_key'];
			$('select#etapes_print_select_multiple').attr('disabled', 'disabled');

			$.get(`${url}/wp-json/etapes-print/api/products/${productId}?api-key=${apiKey}`, function(product, status){
				// loop all options and populate
				const optionKeys = Object.keys(product);
				optionKeys.forEach(option => {
					const selector = `select[name="${option}[]"]`;
					const el = $(selector);
					el.empty();
					const keys = Object.keys(product[option]);
					keys.forEach(key => {
						el.append(`<option value="${key}">${product[option][key]}</option>`);
					});
				});
				$('select#etapes_print_select_multiple').removeAttr('disabled');
			})

			let currentUrlCategory = new URL(window.location.href);
			const idMarketplace = etapes_print_js_object['etapes_print_id_marketplace'];
			$.get(`${url}/wp-json/etapes-print/api/get_remise_by_product/${currentUrlCategory.searchParams.get("ep_category_id")}/products?id_marketplace=${idMarketplace}`, function(product, status){
				$('#_remise_cutomize').val(product[0]['remise']);
			});
		});

		//Produit simple et produit etape print : select option
		$(document).on('change','#product-type',function(){
			if($(this).val() == 'etapes_print'){
				$('.etapes_print_tab').show();  
				$(".etapes_print_tab  a").trigger('click'); 
			} else {
				$('[value="etapes_print"]').removeAttr('selected','selected');
				$('.etapes_print_tab').hide();
			}
		});
		//End produit simple et produit etape print : select option
	});

	//Marge beneficiaire et currency
	$(function(){
			$('#etapes_print_client_product').change(function(e){
				let product = $('#etapes_print_client_product option:selected').text();
				let productValue = $('#title').val();
				if(productValue.length === 0){
					$('#title').attr('value',product);
				}
				$('#title-prompt-text').css('opacity','0');
			});
			$(".tab").click(function (){
				$(this).addClass("button-primary").siblings().removeClass("button-primary");   
			});

			// INIT CURRENCY
			$('._marge_beneficiaire_field label').html('Marge beneficiaire &nbsp;<span class="btn-measure"><span>');
			let currency_ = $('#_marge_beneficiaire_currency').val();
			if(currency_ && currency_.length){
				$('.btn-measure').text('('+currency_+')');
			}else{
				let currency_ = '€';
				$('.btn-measure').text('('+currency_+')');
			}
			// ADD EVENTS
			$('.btn_beneficiaire a').eq(0).click(function(){
				$('.btn-measure').text('(€)');
				let a = $(this).text();
                $('#_marge_beneficiaire_currency').val(a);
			})
			$('.btn_beneficiaire a').eq(1).click(function(){
				$('.btn-measure').text('(%)');
				let a = $(this).text();
                $('#_marge_beneficiaire_currency').val(a);
			})

			let get_measure = $('.btn-measure').text();
			const chars = get_measure.split('');

			function loop_beneficiaire($arg1, $arg2){
				$('.btn_beneficiaire a').each(function(){
					if($(this).text() == $arg1){
						return $(this).addClass('button-primary');
					}
					if($(this).text() == $arg2){
						return $(this).removeClass('button-primary');
					}
				});
			}
			if(chars[1] == '€'){
				loop_beneficiaire('€','%');
			}else{
				loop_beneficiaire('%','€');
			}
	});
	//End Marge beneficiaire et currency

	//Gestionnaire des icones : 

	//panel active/inactive
	$(document).on('click','.app-btn-conserver',function(){
		$(this).addClass("active").siblings().removeClass("active"); 
		let index = $(this).index();

		$('.app-btn-conserver').removeClass('active');
		$(this).addClass('active');
	
		$('.app-tab-pane').removeClass('active');
		$('.app-tab-pane:eq(' + index + ')').addClass('active');
	});

	//modal : ajout icone
	$( document ).on('click','.app-choose-file button', function(){
		$('.app-modal').show();
	});
	$( document ).on('click','.app-close-modal', function(){
		$('.app-modal').hide();
	});

	//Select option 
	$( document ).on('change','#select_option', function(){
		let optionIn = $('#select_option option:selected').val();
		let optionOut = optionIn.replace('_', '-');
		const url = etapes_print_js_object['etapes_print_server_url'];
		const apiKey = etapes_print_js_object['etapes_print_api_key'];
		if (url) {
			$.get(`${url}/wp-json/etapes-print/api/options/etapes-print-${optionOut}/codes?api-key=${apiKey}`, function(options, status){
				const code_option = $('#code_option');
				code_option.empty();
				options.forEach(option => {
					code_option.append(`<option value="${option['code']}">${option['code']}</option>`);
				});
			})
		}
	})

	//Image preview upload
	$( document ).on('change','#upload',function() {
		let fileInput = this;
		if(fileInput.files && fileInput.files[0]) {
		  let reader = new FileReader();
		  reader.onload = function(event) {
			let preview = $('<img class="img_id">').attr('src', event.target.result);
			preview.css('max-width', '110px');
			$(fileInput).after(preview , '<span class="dashicons dashicons-no-alt upload_close"></span>');
			$('body .label-upload').addClass("d-none");
		  };
		  reader.readAsDataURL(fileInput.files[0]);
		}
	  });

	  $( document ).on('click', '.upload_close', function(){
		$(this).prev('img').remove(); // Supprime la miniature de l'image
		$(this).remove(); // Supprime le bouton de fermeture
		$('#upload').val('');
		$('body .label-upload').removeClass("d-none");
	});

	//End Gestionnaire des icones

	//Gestionnaire image

	const propertyMap = {
		'#border-image-color': ['#border-color-img', 'border-color'],
		'#border-image-color-hover': ['#border-color-img-hover', 'border-color'],
		'#boutton-color': ['#button_custom_bg', 'color'],
		'#boutton-bg': ['#button_custom_bg', 'background'],
		'#boutton-border': ['#button_custom_bg', 'border-color'],
		'#boutton-hover-color': ['#button_custom_bg_hover', 'color'],
		'#boutton-hover-bg': ['#button_custom_bg_hover', 'background-color'],
		'#boutton-hover-border': ['#button_custom_bg_hover', 'border-color'],
	  };
	  $(document).on('input', function(event) {
		if (propertyMap && propertyMap['#' + event.target.id]) {
			const [selector, property] = propertyMap['#'+event.target.id];
			const value = $(event.target).val();
			$(selector).css(property, value);
		}
	  });

	//End Gestionnaire image

	//Recapitulatif financier : default
	const url = etapes_print_js_object['etapes_print_server_url'];
	if (url) {
		$( document ).ready(function(){
			let currentUrl = new URL(`${url}/wp-json/etapes-print/v4.0.0/price`);
			const options_list = etapes_print_js_object['options_list'];
			options_list.forEach(option => {
				let option_selected = $('#etapes_print_'+option+'_default_value').val();
				if(option_selected){
					currentUrl.searchParams.append('etapes_print_'+option,option_selected);
				}
			});

			let productType = $('#product-type');
			// Check if 'etapes_print' is selected on page load
			if (productType.val() === 'etapes_print') {
				$.get(currentUrl, function(results) {
					return_add_to_table(results);
				});
			}

			// Check for changes in the selection
			productType.change(function() {
				if ($(this).val() === 'etapes_print') {
					$.get(currentUrl, function(results) {
						return_add_to_table(results);
					});
				}
			});

			//Click display table
			$('.btn_beneficiaire a').each(function() {
				$(this).click(function() {
					load_spinner();
					$.get(currentUrl, function(results) {
						return_add_to_table(results);
					});
				});
			});

			//Change display table
			options_list.forEach(option => {
				$(document).on('change', 'select[name="etapes_print_'+option+'_values[]"]', function() {
					if(currentUrl){
						let select_value = $(this).val();
						if(select_value.length > 1) {
							select_value = $('select[name="etapes_print_'+option+'_default_value"]').val();
						}
						currentUrl.searchParams.set('etapes_print_'+option, select_value);
						$.get(currentUrl, function(results){
							return_add_to_table(results);
						});
					}
				});
				$(document).on('click', 'select[name="etapes_print_'+option+'_values[]"]', function() { 
					load_spinner();
				});


				$(document).on('change', 'select[name="etapes_print_'+option+'_default_value"]', function() {
					if(currentUrl){
						const select_value = $(this).val();
						currentUrl.searchParams.set('etapes_print_'+option, select_value);
						load_spinner();
						$.get(currentUrl, function(results){
							return_add_to_table(results);
						});
					}
				});
			});
		});
	}
	
	let prix_fournisseur = null;
	let prix_etapes_print = null;
	let prix_marketplace = null;
	let prix_revient = null;

	function load_spinner(){
		$('.load-spinner').show();
		$('.recap_finance table').css('opacity','0.3');
	}

	function return_add_to_table(results){
		$('.load-spinner').hide();
		$('.recap_finance table').css('opacity','1');
		add_to_table(results);
	}

	function add_to_table(data){
		// Variables
		const remise = $('#_remise_cutomize').val();
		if(remise && remise.length){
		const numberRemise = parseFloat(remise);
		const currency_remise = remise.slice(-1);
		//const currency_remise = '%';

		const marge = parseFloat($('#_marge_beneficiaire').val());
		const currrency_names = $('._marge_beneficiaire_field .btn-measure').text();
		let currency_name_marge = currrency_names.substring(1, 2);
		//const currency_name_marge = '%';

		const recapfinance = $('#recapFinance tbody');
		recapfinance.empty();

		let first = true;

		//Add data to table
		Object.entries(data.prices).forEach(([key, value]) => {
			// quantity_price : get quantity value
			const quantity_price = $('#etapes_print_quantity_price_array').val();
			const quantity_price_val = quantity_price.split(',');
			quantity_price_val.forEach(element => {
				if(key === element){

					//Change currency_name_marge value after click
					let get_measure = $('.btn-measure').text();
					const chars = get_measure.split('');
					if(chars[1] == '€'){
						currency_name_marge = '€';
					}else{
						currency_name_marge = '%';
					}

					calculateTable(currency_name_marge, currency_remise, numberRemise, marge, value);	
					
					if (first) {
						$('#_regular_price').val(prix_marketplace.toFixed(2));
						first = false;
					}

					recapfinance.append(`
					<tr>
						<td>${key}</td>
						<td>${prix_fournisseur.toFixed(2)}€</td>
						<td>${prix_etapes_print.toFixed(2)}€</td>
						<td>${prix_marketplace.toFixed(2)}€</td>
						<td>${prix_revient.toFixed(2)}€</td>
					</tr>`);
				}
			});
		});
		}
	}

	function calculateTable(currency_name_marge, currency_remise, numberRemise, marge, value){
		prix_etapes_print = value;
		if (currency_name_marge == '€' && currency_remise == '€'){
			prix_fournisseur = prix_etapes_print - numberRemise;
			prix_marketplace = prix_fournisseur +  marge;
		} else if (currency_name_marge == '%' && currency_remise == '%'){
			prix_fournisseur = prix_etapes_print * (1 - numberRemise / 100);
			prix_marketplace = prix_fournisseur * ( 1 + marge / 100 );
		} else if (currency_name_marge == '%' && currency_remise == '€'){
			prix_fournisseur = prix_etapes_print - numberRemise;
			prix_marketplace = prix_fournisseur * ( 1 + marge / 100 );
		} else if (currency_name_marge == '€' && currency_remise == '%'){
			prix_fournisseur = prix_etapes_print * (1 - numberRemise / 100);
			prix_marketplace = prix_fournisseur +  marge;
		}
		prix_revient = prix_marketplace - prix_fournisseur;
	}

	//Points module
	$(document).ready(function(){
		const point_order_total = $('#point_order_total').val();
		if(point_order_total){
			const get_total  = $('#point_order_total + .wc-order-totals tbody tr:last, #point_order_total + .wc-order-totals tbody tr:last');
			get_total.find('.total bdi').html(point_order_total + '<span class="woocommerce-Price-currencySymbol">&nbsp;€</span>');
			$('.wc-order-totals').each(function() {
				if ($(this).attr('style')) {
				  const text_last = $(this).find('.tbody tr td:last');
				  text_last.find('.total bdi').html(point_order_total + '<span class="woocommerce-Price-currencySymbol">&nbsp;€</span>');
				}
			});
			$('.wc-order-totals').each(function() {
				if ($(this).attr('style')) {
				$(this).find('tbody tr .total span bdi').html(point_order_total + '<span class="woocommerce-Price-currencySymbol">&nbsp;€</span>');
				}
			});
			$('.wc-order-totals tbody tr .refunded-total').first().each(function() {
				const row = '<tr>' +
							'<td class="label refunded-total">Points remboursés:</td>' +
							'<td width="1%"></td>' +
							'<td class="refunded-total">' +
							'<span class="woocommerce-Price-amount amount"><bdi>'+ $('.redeemed_point_get').text() +'</bdi></span>' +
							'</td>' +
						'</tr>';
				$(this).closest('tr').after(row);
			});
		}
	})
	
	//Change status to completed 
	$(document).ready(function($) {
		const chrono = $('.chrono-order-settings .chrono-print').length;
		const orderId = $('.chrono-generate-label').data('order-id');
		if(chrono && orderId && myAjax){
			const data = {
				'action': 'update_order_status',
				'chronopost' : chrono,
				'orderId' : orderId,
            			'security' : myAjax.security
			};
			$('#order_status').attr('disabled', true);
			$.post(myAjax.ajax_url, data, function(response) {
				if (response.success) {
					$('#order_status option').each(function(){
						$('#order_status').attr('disabled', false);
	                    if(this.value == 'wc-completed'){
	                       $(this).attr('selected','selected');    
	                    }else{
	                        $(this).removeAttr('selected'); 
	                    }
	                });
	                $('#select2-order_status-container').attr('title','Terminée');
	                $('#select2-order_status-container').text('Terminée');
				} else {
					$('#order_status').attr('disabled', false);
					console.log('Error updating order status.');
				}
			});
		}
	});	

})( jQuery );
