<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       x
 * @since      2.0.5
 *
 * @package    Etapes_Print child
 * @subpackage Etapes_Print/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      2.0.5
 * @package    Etapes_Print child
 * @subpackage Etapes_Print/includes
 * @author     Njakasoa Rasolohery <ras.njaka@gmail.com>
 */
class Etapes_Print {

	/**
	 * The loader that's responsible for maintaining and registering all hooks that power
	 * the plugin.
	 *
	 * @since    2.0.5
	 * @access   protected
	 * @var      Etapes_Print_Loader    $loader    Maintains and registers all hooks for the plugin.
	 */
	protected $loader;

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since    2.0.5
	 * @access   protected
	 * @var      string    $plugin_name    The string used to uniquely identify this plugin.
	 */
	protected $plugin_name;

	/**
	 * The current version of the plugin.
	 *
	 * @since    2.0.5
	 * @access   protected
	 * @var      string    $version    The current version of the plugin.
	 */
	protected $version;


	/**
	 * DATASET
	 *
	 * @since    2.0.5
	 * @access   protected
	 * @var      Etapes_Print_Dataset    $dataset
	 */
	protected $dataset;

	/**
	 * Define the core functionality of the plugin.
	 *
	 * Set the plugin name and the plugin version that can be used throughout the plugin.
	 * Load the dependencies, define the locale, and set the hooks for the admin area and
	 * the public-facing side of the site.
	 *
	 * @since    2.0.5
	 */
	public function __construct() {
		if ( defined( 'ETAPES_PRINT_VERSION' ) ) {
			$this->version = ETAPES_PRINT_VERSION;
		} else {
			$this->version = '2.0.5';
		}
		$this->plugin_name = 'etapes-print-client';

		$this->load_dependencies();
		$this->set_locale();
		$this->set_routes();
		$this->define_admin_hooks();
		$this->define_public_hooks();

	}

	/**
	 * Load the required dependencies for this plugin.
	 *
	 * Include the following files that make up the plugin:
	 *
	 * - Etapes_Print_Loader. Orchestrates the hooks of the plugin.
	 * - Etapes_Print_i18n. Defines internationalization functionality.
	 * - Etapes_Print_Router. Defines studio routes.
	 * - Etapes_Print_Admin. Defines all hooks for the admin area.
	 * - Etapes_Print_Public. Defines all hooks for the public side of the site.
	 *
	 * Create an instance of the loader which will be used to register the hooks
	 * with WordPress.
	 *
	 * @since    2.0.5
	 * @access   private
	 */
	private function load_dependencies() {
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-etapes-print-dataset.php';

		/**
		 * The class responsible for orchestrating the actions and filters of the
		 * core plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-etapes-print-loader.php';

		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-etapes-print-i18n.php';

		/**
		 * The class responsible for defining all actions that occur in the router area.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-etapes-print-router.php';

		/**
		 * The class responsible for defining all actions that occur in the admin area.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-etapes-print-admin.php';

		/**
		 * The class responsible for defining all actions that occur in the public-facing
		 * side of the site.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-etapes-print-public.php';

		$this->loader = new Etapes_Print_Loader();
		$this->dataset = new Etapes_Print_Dataset();

	}

	/**
	 * Define the locale for this plugin for internationalization.
	 *
	 * Uses the Etapes_Print_i18n class in order to set the domain and to register the hook
	 * with WordPress.
	 *
	 * @since    2.0.5
	 * @access   private
	 */
	private function set_locale() {

		$plugin_i18n = new Etapes_Print_i18n();

		$this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );

	}

	/**
	 * Register all of the hooks related to the studio area functionality
	 * of the plugin.
	 *
	 * @since    2.0.5
	 * @access   private
	 */
	private function set_routes() {
		$plugin_routes = new Etapes_Print_Router();
		$this->loader->add_filter( 'template_include', $plugin_routes, 'include_template' );
		$this->loader->add_filter( 'init', $plugin_routes, 'flush_rules' );
	}

	/**
	 * Register all of the hooks related to the admin area functionality
	 * of the plugin.
	 *
	 * @since    2.0.5
	 * @access   private
	 */
	private function define_admin_hooks() {

		$plugin_admin = new Etapes_Print_Admin( $this->get_plugin_name(), $this->get_version(), $this->get_dataset() );

		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles' );
		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts' );
		$this->loader->add_action( 'admin_menu', $plugin_admin, 'add_menu' );

		$this->loader->add_action( 'woocommerce_process_product_meta', $plugin_admin, 'save_fields', 10, 2 );

		// Add Etapes Print Settings
		$this->loader->add_filter( 'woocommerce_product_data_tabs', $plugin_admin, 'product_settings_tabs' );
		$this->loader->add_action( 'woocommerce_product_data_panels', $plugin_admin, 'product_panels' );

		// REST API
		$this->loader->add_action( 'rest_api_init', $plugin_admin, 'init_admin_route' );

		// $this->loader->add_action( 'admin_init', $plugin_admin, 'getproductApi');
		
		// NEW PRODUCT TYPE
		$this->loader->add_action( 'init', $plugin_admin, 'register_etapes_print_product_type' );
		$this->loader->add_filter( 'product_type_selector', $plugin_admin, 'add_etapes_print_product_type' );
		$this->loader->add_filter( 'woocommerce_product_class', $plugin_admin, 'set_etapes_print_product_class', 10, 3 );
		// $this->loader->add_action('woocommerce_product_options_general_product_data', $plugin_admin, 'product_general_panel');

		$this->loader->add_action( 'woocommerce_admin_order_data_after_billing_address', $plugin_admin, 'display_order_details' );
		// $this->loader->add_action( 'save_post_shop_order', $plugin_admin, 'update_order_option', 10, 2 );
		$this->loader->add_action( 'woocommerce_admin_order_totals_after_tax', $plugin_admin, 'modify_admin_order_totals', 10, 1 );
		$this->loader->add_action( 'wpo_wcpdf_after_order_details' , $plugin_admin, 'display_earned_redeemed_message' , 20 , 2 ) ;

		$this->loader->add_filter('woocommerce_order_item_display_meta_key', $plugin_admin, 'add_custom_metadata_to_order_items', 10, 3);
		$this->loader->add_action('woocommerce_checkout_update_order_meta', $plugin_admin, 'move_uploaded_file_after_order_created', 20, 2);

		$this->loader->add_action('wp_ajax_update_order_status', $plugin_admin, 'update_order_status_ajax');
		$this->loader->add_action('wp_ajax_nopriv_update_order_status', $plugin_admin, 'update_order_status_ajax'); // For non-logged-in users

	}

	/**
	 * Register all of the hooks related to the public-facing functionality
	 * of the plugin.
	 *
	 * @since    2.0.5
	 * @access   private
	 */
	private function define_public_hooks() {

		$plugin_public = new Etapes_Print_Public( $this->get_plugin_name(), $this->get_version(), $this->get_dataset() );


		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_styles' );
		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_scripts' );

		$this->loader->add_action( 'woocommerce_get_price_html', $plugin_public, 'get_price_html', 20, 2 );

		/**
		 * Enable REST API to Etapes Print Server
		 */
		$this->loader->add_action('rest_authentication_errors', $plugin_public, 'force_login_bypass', 1, 1);

		/**
		 * Edit cart product before
		 */
		$this->loader->add_filter( 'woocommerce_add_cart_item_data', $plugin_public, 'add_cart_item_data', 15, 3 );
		$this->loader->add_action('woocommerce_add_to_cart_redirect', $plugin_public, 'add_product_to_cart_via_url');
		$this->loader->add_action('woocommerce_add_to_cart_validation', $plugin_public, 'validate_product_add_to_cart', 10, 3);


		$this->loader->add_filter('woocommerce_get_item_data', $plugin_public,'get_item_data', 10, 2);
		$this->loader->add_action( 'woocommerce_checkout_create_order_line_item', $plugin_public, 'checkout_create_order_line_item', 10, 4 );
		// $this->loader->add_action( 'woocommerce_cart_item_removed', $plugin_public, 'remove_cart_action', 10, 2 );
		// $this->loader->add_filter( 'woocommerce_is_sold_individually', $plugin_public, 'is_sold_individually', 10, 2 );
		// $this->loader->add_action( 'woocommerce_before_calculate_totals', $plugin_public, 'before_calculate_totals', 20, 1 );

		// $this->loader->add_filter( 'woocommerce_cart_item_quantity', $plugin_public, 'cart_item_quantity', 10, 3);


		/**
		 * For Dev only
		 */
		// $this->loader->add_filter( 'woocommerce_cart_needs_payment', $plugin_public, 'cart_needs_payment', 10, 2 ); 

		$this->loader->add_action('wp_ajax_add_info_cart_item', $plugin_public, 'add_info_cart_item');
		$this->loader->add_action('wp_ajax_nopriv_add_info_cart_item', $plugin_public,'add_info_cart_item');
		$this->loader->add_action( 'woocommerce_before_calculate_totals', $plugin_public,'add_custom_price' );

		$this->loader->add_action('wp_ajax_get_variation_id_callback', $plugin_public, 'get_variation_id_callback');
		$this->loader->add_action('wp_ajax_nopriv_get_variation_id_callback', $plugin_public,'get_variation_id_callback');

		$this->loader->add_action('woocommerce_after_cart', $plugin_public, 'notice_woocommerce_variable');

		$this->loader->add_action( 'woocommerce_cart_totals_before_order_total',$plugin_public, 'add_apply_discount_button' );
		$this->loader->add_filter('woocommerce_calculated_total',$plugin_public, 'change_total_cart_value', 10, 2);
		$this->loader->add_action('wp_ajax_get_total_cart',$plugin_public, 'get_total_cart');
		$this->loader->add_action('wp_ajax_nopriv_get_total_cart',$plugin_public, 'get_total_cart');
		$this->loader->add_action('wp_ajax_add_exchange_point',$plugin_public, 'add_exchange_point');
		$this->loader->add_action('wp_ajax_nopriv_add_exchange_point',$plugin_public, 'add_exchange_point');

		$this->loader->add_action( 'woocommerce_review_order_after_shipping',$plugin_public, 'custom_hook_before_tax_cart_page' );
		$this->loader->add_action( 'woocommerce_cart_totals_after_shipping',$plugin_public, 'custom_hook_before_tax_cart_page' );

		$this->loader->add_action('wp_ajax_update_point_up',$plugin_public, 'update_point_up');
		$this->loader->add_action('wp_ajax_nopriv_update_point_up',$plugin_public, 'update_point_up');
		
		$this->loader->add_action('wp_ajax_remove_points',$plugin_public, 'remove_points');
		$this->loader->add_action('wp_ajax_nopriv_remove_points',$plugin_public, 'remove_points');

		$this->loader->add_action('wp_ajax_update_point_used',$plugin_public, 'update_point_used');
		$this->loader->add_action('wp_ajax_nopriv_update_point_used',$plugin_public, 'update_point_used');

		$this->loader->add_action('woocommerce_checkout_update_order_meta', $plugin_public, 'save_custom_input_to_order_meta');
		$this->loader->add_action('wp_ajax_update_info_cart_item', $plugin_public, 'update_info_cart_item');
		$this->loader->add_action('wp_ajax_nopriv_update_info_cart_item', $plugin_public,'update_info_cart_item');
	}

	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 *
	 * @since    2.0.5
	 */
	public function run() {
		$this->loader->run();
	}

	/**
	 * The name of the plugin used to uniquely identify it within the context of
	 * WordPress and to define internationalization functionality.
	 *
	 * @since     2.0.5
	 * @return    string    The name of the plugin.
	 */
	public function get_plugin_name() {
		return $this->plugin_name;
	}

	/**
	 * The reference to the class that orchestrates the hooks with the plugin.
	 *
	 * @since     2.0.5
	 * @return    Etapes_Print_Loader    Orchestrates the hooks of the plugin.
	 */
	public function get_loader() {
		return $this->loader;
	}

	/***	
	 * Retrieve the version number of the plugin.
	 *
	 * @since     2.0.5
	 * @return    string    The version number of the plugin.
	 */
	public function get_version() {
		return $this->version;
	}

	public function get_dataset() {
		return $this->dataset;
	}

}
