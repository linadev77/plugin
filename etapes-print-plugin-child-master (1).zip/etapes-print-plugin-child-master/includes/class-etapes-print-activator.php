<?php

/**
 * Fired during plugin activation
 *
 * @link       x
 * @since      2.0.5
 *
 * @package    Etapes_Print
 * @subpackage Etapes_Print/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      2.0.5
 * @package    Etapes_Print
 * @subpackage Etapes_Print/includes
 * @author     Njakasoa Rasolohery <ras.njaka@gmail.com>
 */
class Etapes_Print_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    2.0.5
	 */
	public static function activate() {
		global $wpdb;
		$charset_collate = $wpdb->get_charset_collate();

		
		$table_name = $wpdb->prefix."etapes_print_select_rule";
		$sql_create_select_rule = "CREATE TABLE IF NOT EXISTS `$table_name` (
			`id` mediumint(11) NOT NULL AUTO_INCREMENT,
			`code` varchar(80) NOT NULL,
			`select` varchar(1000),
			`denies` varchar(1000),
			PRIMARY KEY  (`id`, `code`)
			) ENGINE=MyISAM DEFAULT CHARSET=latin1;";
		$sql_drop_select_rule = "DROP TABLE IF EXISTS `$table_name`;";

		$table_name = $wpdb->prefix."etapes_print_deny_rule";
		$sql_create_deny_rule = "CREATE TABLE IF NOT EXISTS `$table_name` (
			`id` mediumint(11) NOT NULL AUTO_INCREMENT,
			`code` varchar(80) NOT NULL,
			`deny` varchar(1000),
			PRIMARY KEY  (`id`, `code`)
			) ENGINE=MyISAM DEFAULT CHARSET=latin1;";
		$sql_drop_deny_rule = "DROP TABLE IF EXISTS `$table_name`;";

		$table_name = $wpdb->prefix."etapes_print_options_codes";
		$sql_create_options_codes = "CREATE TABLE IF NOT EXISTS `$table_name` (
			`id` mediumint(11) NOT NULL AUTO_INCREMENT,
			`code` varchar(80) NOT NULL,
			`url` varchar(250),
			PRIMARY KEY  (`id`, `code`)
			) ENGINE=MyISAM DEFAULT CHARSET=latin1;";
		$sql_drop_options_codes = "DROP TABLE IF EXISTS `$table_name`;";

		$table_name = $wpdb->prefix."etapes_print_add_info_cart_item";
		$sql_create_add_info_cart_item = "CREATE TABLE IF NOT EXISTS `$table_name` (
			`id` mediumint(11) NOT NULL AUTO_INCREMENT,
			`id_user` smallint(11) NULL,
			`id_product` smallint(11) NULL,
			`info_cart_item` text NULL,
			PRIMARY KEY  (`id`)
			) ENGINE=MyISAM DEFAULT CHARSET=latin1;"; 
		$sql_drop_add_info_cart_item = "DROP TABLE IF EXISTS `$table_name`;";

		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
	
		// dbDelta($sql_create_select_rule);
		// dbDelta($sql_create_deny_rule);
		// dbDelta($sql_create_options_codes);
		// dbDelta($sql_drop_add_info_cart_item);
		// dbDelta($sql_create_add_info_cart_item);


		if (!get_option('etapes_print_server_url')) {
			update_option('etapes_print_server_url', 'https://etapes-print.com');
		}
	}



}
