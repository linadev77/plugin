<div id="variation-selection">
    <input type="hidden" name="data-variations" class="variations-scoop">
    <?php

    //First variation default value
    $variation_id = 0;
    $variation_price = 0;
    $product = wc_get_product($product_id);
    if ($product && $product->is_type('variable')) {
        $variations = $product->get_children();
        foreach ($variations as $variation_id) {
            $variation = wc_get_product($variation_id);
            $variation_id = $variation->get_id();
            $variation_price = $variation->get_price();
            break;
        }
    }

    //Display variation data
    $variation = wc_get_product($variation_id);
    $array = array();
    if ($variation && $variation->is_type('variation')) {
        foreach ($variation->get_variation_attributes() as $attribute_name => $attribute_value) {
            $attribute_label = wc_attribute_label($attribute_name);
            $term = get_term_by('slug', $attribute_value, $attribute_name);
            if ($term) {
                $term_name = $term->name;
            } else {
                $term_name = $attribute_value;
            }
            array_push($array, $term_name);
        }
    }

    //List attributs actif
    $used_terms = array();
    $variations = $product->get_children();
    foreach ($variations as $variation_id) {
        $variation = wc_get_product($variation_id);
        $variation_attributes = $variation->get_variation_attributes();
        foreach ($variation_attributes as $attribute => $value) {
            $used_terms[$attribute][] = $value;
        }
    }

    //Change key name
    $new_used_terms = array_combine(
        array_map(function ($key) {
            return str_replace('attribute_', '', $key);
        }, array_keys($used_terms)),
        array_values($used_terms)
    );

    $attributes = $product->get_variation_attributes();

    //Loop : labels and values variations 
    foreach ($attributes as $attribute_name => $attribute_values) { ?>
        <?php $attribute_label = wc_attribute_label($attribute_name);
        if (isset($new_used_terms[$attribute_name])) { ?>
            <div class="variations-labels">
                <h3><?= esc_html($attribute_label) ?></h3>
                <select name="attribute_<?= sanitize_title($attribute_name) ?>" id="" class="variation-dropdown <?= esc_attr($attribute_name) ?>">
                    <?php foreach ($attribute_values as $attribute_value) { ?>
                        <?php if (in_array($attribute_value, $new_used_terms[$attribute_name])) { 
                            $term = get_term_by('slug', $attribute_value, $attribute_name);
                            ?>
                            <option value="<?= esc_attr($attribute_value) ?>" <?php echo in_array($attribute_value, $array) ? 'selected="selected"' : ''; ?>>
                                <?= esc_html(apply_filters('woocommerce_variation_option_name', $term->name)) ?>
                            </option>
                        <?php } ?>
                    <?php } ?>
                </select>
            </div>
            <br>
        <?php } ?>
    <?php } ?>

    <div>
        <ins>
            <span class="load-spinner"><i class="fas fa-spinner"></i></span>
            <span class="woocommerce-Price-amount-sp amount"><span id="price_current"></span></span>
        </ins>
    </div>
    <input type="hidden" id="variations-id-default" value="<?= $variation_id ?>">
    <input type="hidden" id="variations-price-default" value="<?= $variation_price ?>">

</div>