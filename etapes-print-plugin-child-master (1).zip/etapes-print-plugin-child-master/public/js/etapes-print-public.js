(function( $ ) {
	'use strict';

	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */

	/**********
	 Cart point Module
	***********/
	$(document).ready(function() {
		$('.points_after_order').hide();
		$(document).on('change', '.woocommerce-cart #shipping_method input#pay_ship_with_point',function(){
			let shipping_value = parseFloat($('.shipping_value:last').val());
			let isChecked = $(this).is(':checked');
			let setData = {
				action: "get_total_cart",
				isChecked : isChecked,
			}
			$('.woocommerce-cart .cart_totals').addClass('zoom_point');
			$.post(my_ajax_obj.ajax_url, setData, function(data, status) {
				$('.woocommerce-cart .cart_totals').removeClass('zoom_point');
				$('.points_after_order').toggle(isChecked);
				setTimeout(() => {
					let startIndex = data.indexOf("{");
					let endIndex = data.indexOf("}");
					let jsonString = data.substring(startIndex, endIndex + 1);
					let jsonObject = JSON.parse(jsonString);
					let total_order = parseFloat(jsonObject.total);
					if (shipping_value) {
						try {
							let result = isChecked ? total_order - shipping_value : total_order;
							$('.order-total .woocommerce-Price-amount bdi').html(result.toFixed(2) + '<span class="woocommerce-Price-currencySymbol">&nbsp;€</span>');
							let point = parseFloat($('#point_available').text());
							let point_available = point + (isChecked ? -shipping_value : shipping_value);
							$('#point_available').text(point_available.toFixed(2) + ' (' + point_available.toFixed(2) + ' €)');
							let href = $('.wc-proceed-to-checkout .checkout-button').attr('href');
							$('.wc-proceed-to-checkout .checkout-button').attr('href', href + '?wp-points=true');
						} catch (error) {
							console.error(error);
						}
					}
				}, 100);							
			});	
		});

		//Updated shipping method : radio button loading
		$(document.body).on('updated_shipping_method', function() {
			const redeemed_point_post = $('#redeemed_point_post').val();
			if(redeemed_point_post == 0){
				$('.tr_apply_coupon.point_redeemed_market').hide();
				return;
			}
			$('.woocommerce-remove-coupon.rsc').html('<span class="enlever_point">[Enlever]</span>');
		});

		// Select the target element to observe
		$('#rs_apply_coupon_code_field').after('<div style="margin:7px 0px"><input type=checkbox id=apply_points_all_cart><span>Payer le total de ma commande avec mes points</span></div>');
		const targetElement = $('.woocommerce')[0];
		if (targetElement) {
			// Create a new MutationObserver instance
			const observer = new MutationObserver((mutationsList) => {
				// Check each mutation that occurred
				for (const mutation of mutationsList) {
					// Check if nodes were added
					if (mutation.type === 'childList') {
					// Check if any added node matches the desired criteria
					$(mutation.addedNodes).each((index, node) => {
						if ($(node).hasClass('woocommerce-cart-form')) {
							$('#rs_apply_coupon_code_field').after('<div style="margin:7px 0px"><input type=checkbox id=apply_points_all_cart><span>Payer le total de ma commande avec mes points</span></div>');
							const redeemed_point_post = $('#redeemed_point_post').val();
							if(redeemed_point_post == 0){
								$('.tr_apply_coupon.point_redeemed_market').hide();
							};
						}
					});
					}
				}
			});
			// Start observing the target element for mutations
			observer.observe(targetElement, { childList: true });
		}

		// input checkbox : assign value to input point [Payer le total de ma commande avec mes points]
		$(document).on('change', '.woocommerce-cart input#apply_points_all_cart',function(){
			const str = $('.order-total .woocommerce-Price-amount bdi').text();
			const number = parseFloat(str.replace(/[^\d.,]/g, '').replace(',', '.'));
			console.log('wawawa', str);
			const roundedNumber = Math.ceil(number);
			if ($(this).is(':checked')) {
				$('#rs_apply_coupon_code_field').val(roundedNumber);
				$("#rs_apply_coupon_code_field").css({
					'pointer-events':'none',
					'border-color': '#efefef',
					'color': '#efefef',
				});
			}else{
				$("#rs_apply_coupon_code_field").css({
					'pointer-events':'auto',
					'border-color': 'var(--form_border_color)',
					'color': '#747474',
				});
			}
		});

		//Assign value point to database : [appliquer des points optimarket]
		$(document).on('click', '.woocommerce-cart .woocommerce .fp_apply_reward input#mainsubmi',function(e){
			e.preventDefault();
			const str = $('.order-total .woocommerce-Price-amount bdi').text();
			const number = parseFloat(str.replace(/[^\d.,]/g, '').replace(',', '.'));
			const cartPricePoint = Math.ceil(number);
			const userInputPoint = $('#rs_apply_coupon_code_field').val();

			const roundedNumber = Math.min(cartPricePoint, userInputPoint);
			const priceTTC = Math.max(number - userInputPoint, 0).toFixed(2).replace('.', ',');
			
			const setData = {
				action: "update_point_up",
				isCheckedTwo : roundedNumber,
			}

			$.post(my_ajax_obj.ajax_url, setData, function(data, status) {
				window.location.reload();
			});
		});
		
		const redeemed_point_post = $('#redeemed_point_post').val();
		$('.point_redeemed_market').css('display','none');
		if(redeemed_point_post > 0){
			$('.point_redeemed_market').css('display','contents');
			$("#rs_apply_coupon_code_field").css({
				'pointer-events':'none',
				'border-color': '#efefef',
				'color': '#efefef',
			});
			$('#mainsubmi,#apply_points_all_cart').css({
				'opacity': '0.5',
    			'pointer-events': 'none'
			})
			$('#rs_apply_coupon_code_field').val(redeemed_point_post);
		}

		$('.woocommerce-remove-coupon.rsc').html('<span class="enlever_point">[Enlever]</span>');

		//Remove point on the cart : [enlever]
		$(document.body).on( 'click', '.woocommerce-remove-coupon', function(e) {
			e.preventDefault();
			const setData = {
				action: "remove_points",
				remove_coupons_all: 2
			};
			$.post(my_ajax_obj.ajax_url, setData, function(response) {
				window.location.reload();
			});
		});

		//Dokan : demande de devis - disabled input prix customer
		$('.woocommerce-account .offered-price-input').attr('disabled','disabled');
	})

	/************
	End Cart point Module
	***********/

})( jQuery );
