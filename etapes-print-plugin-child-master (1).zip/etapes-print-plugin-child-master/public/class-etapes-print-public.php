<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       x
 * @since      2.0.5
 *
 * @package    Etapes_Print
 * @subpackage Etapes_Print/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Etapes_Print
 * @subpackage Etapes_Print/public
 * @author     Njakasoa Rasolohery <ras.njaka@gmail.com>
 */
class Etapes_Print_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    2.0.5
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    2.0.5
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	private $dataset;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    2.0.5
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version, $dataset ) {
		require_once ABSPATH . 'wp-admin/includes/image.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';

		$this->plugin_name = $plugin_name;
		$this->version = $version;
		$this->dataset = $dataset;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    2.0.5
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Etapes_Print_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Etapes_Print_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/etapes-print-public.css?ver=2.0.5', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    2.0.5
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Etapes_Print_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Etapes_Print_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		 if(wc_get_product( get_the_ID())){
			$get_id_product = wc_get_product( get_the_ID()) ;
			$get_type_product = $get_id_product->get_type();
		}else{
			$get_type_product = '';
		}
		if ( get_post_meta( get_the_ID(), 'etapes_print_quantity', true ) || $get_type_product === 'variable'){
			wp_enqueue_script('vue', 'https://unpkg.com/vue@3', [], '3', true);
			wp_enqueue_script('pdf', 'https://cdn.jsdelivr.net/npm/pdfjs-dist@2.10.377/build/pdf.min.js', [], '3', true);
			
			wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/etapes-print-public-display.js', array( 'jquery' ), $this->version, true );
			wp_localize_script( $this->plugin_name , 'myAjax', array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'security' => wp_create_nonce( 'my-ajax-nonce' )
			));

			$data = array();
			foreach ($this->dataset->get_options() as $option) {
				if ($option === 'production') {
					$etapes_print_delay_delivery = get_post_meta( get_the_ID(), 'etapes_print_' . $option . '_delay', true );
					if (!$etapes_print_delay_delivery) {
						$etapes_print_delay_delivery = get_option('etapes_print_delay_delivery');
					}
					$data['delay_delivery'] = $etapes_print_delay_delivery;
				} else if (get_post_meta( get_the_ID(), 'etapes_print_' . $option, true )) {
					if ($option === 'cover') {
						$cover_code = get_post_meta( get_the_ID(), 'etapes_print_' . $option . '_value', true );
						$etapes_print_cover = $this->dataset->get_cover_by_code($cover_code);
						$data['cover'] = $etapes_print_cover;
					} else if ($option === 'select_rules') {
						$select_rule_codes = get_post_meta( get_the_ID(), 'etapes_print_' . $option . '_values', true );
						$data[$option] = $this->dataset->get_select_rules_by_codes($select_rule_codes);
					} else if ($option === 'custom_format') {
						$etapes_print_format_width = get_post_meta( get_the_ID(), 'etapes_print_' . $option . '_width', true );
						$etapes_print_format_height = get_post_meta( get_the_ID(), 'etapes_print_' . $option . '_height', true );
						$data[$option] = array( 
							'width' => $etapes_print_format_width,
							'height' => $etapes_print_format_height
						);
					} else if ($option === 'quantity') {
						$etapes_print_quantity_price_array = get_post_meta( get_the_ID(), 'etapes_print_' . $option . '_price_array', true );
						if (!$etapes_print_quantity_price_array) {
							$etapes_print_quantity_price_array = get_option('etapes_print_price_array');
						}
						$etapes_print_quantity_default_quantity = get_post_meta( get_the_ID(), 'etapes_print_' . $option . '_default_quantity', true );
						if (!$etapes_print_quantity_default_quantity) {
							$etapes_print_quantity_default_quantity = get_option('etapes_print_default_quantity');
						}
						$data['price_array'] = $etapes_print_quantity_price_array;
						$data['default_quantity'] = $etapes_print_quantity_default_quantity;

						$etapes_print_quantity_min = get_post_meta( get_the_ID(), 'etapes_print_' . $option . '_min', true );
						$etapes_print_quantity_max = get_post_meta( get_the_ID(), 'etapes_print_' . $option . '_max', true );
						$data[$option] = array( 
							'min' => $etapes_print_quantity_min,
							'max' => $etapes_print_quantity_max
						);
					} else if (	get_post_meta( get_the_ID(), 'etapes_print_' . $option . '_values', true ) &&
					get_post_meta( get_the_ID(), 'etapes_print_' . $option . '_default_value', true ) ) {
						$etapes_print_options_values = get_post_meta( get_the_ID(), 'etapes_print_' . $option . '_values', true );
						$etapes_print_default_value = get_post_meta( get_the_ID(), 'etapes_print_' . $option . '_default_value', true );
						$data[$option] = array( 
							'options_values' => $etapes_print_options_values,
							'default_value' => $etapes_print_default_value
						);
					}
				}
			}
			$data['delivery_price'] = get_option('etapes_print_delivery_price');
			$data['marge_beneficiaire'] = get_post_meta( get_the_ID(), '_marge_beneficiaire', true );
			$data['marge_beneficiaire_currency'] = get_post_meta( get_the_ID(), '_marge_beneficiaire_currency', true );
			$data['api_key'] = get_option('etapes_print_api_key');
			wp_localize_script( $this->plugin_name, 'etapes_print_vue_object', $data);
		}  

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/etapes-print-public.js', array( 'jquery' ), $this->version, false );

		$nonce = wp_create_nonce("get_cart_item_nonce");
		wp_localize_script( $this->plugin_name , 'my_ajax_obj', array( 'ajax_url' => admin_url( 'admin-ajax.php' ), 'nonce' => $nonce ) );
		
	}

	public function product_variations() {
		global $product;
		$options = $this->dataset->get_options();
		$custom_options = get_option( 'etapes_print_customized_option', '' );
		$etapes_print_cover = null;

		if ( $product ) {
            $product_id = $product->get_id();
			$product_type = wc_get_product( $product_id );		
        }
		if (get_post_meta( get_the_ID(), 'etapes_print_cover', true )) {
			$cover_code = get_post_meta( get_the_ID(), 'etapes_print_cover_value', true );
			if ($cover_code) {
				$etapes_print_cover = $this->dataset->get_cover_by_code($cover_code);
				$cover = array(
					'format' => explode(',', $etapes_print_cover['format']),
					'paper' => explode(',', $etapes_print_cover['paper'])
				);
	
				// mettre pelliculage en premier dans l'affichage
				$key = array_search('refinement', $options);
				array_splice($options, $key, 1);
				array_unshift($options, 'refinement');
			}
		}


		include( plugin_dir_path( __FILE__ ) . 'partials/etapes-print-public-display.php' );
	}

	public function add_cart_item_data($cart_item_data, $product_id, $variation_id) {
		$options = $this->dataset->get_options();
		$id_user = get_current_user_id();

		global $wpdb;
		$table_name = $wpdb->prefix . 'etapes_print_add_info_cart_item';
		$query = "SELECT * FROM $table_name WHERE id_product = '$product_id' AND id_user = '$id_user' ";
		$result =  $wpdb->get_row(  $query );
		$array = unserialize($result->info_cart_item);
		foreach ($array as $key => $value) {
			$cart_item_data['etapes_print'][$key] = $value;                                                                                                                                                                                                        
		}
		$wpdb->delete( $table_name, array( 'id_product' => $product_id, 'id_user' => $id_user ) );

    	return $cart_item_data;
	}

	public function get_item_data($item_data, $cart_item) {
		$product = $cart_item['data'];
		$item_meta_data = $product->get_meta_data();
		

		if(isset($cart_item['etapes_print'])){
			$etapes_print_info = $cart_item['etapes_print'];
			if ($etapes_print_info) {
				if (isset($cart_item['etapes_print']['Quantité'])) {
					echo '<br><b>Quantité:</b> ' . $cart_item['etapes_print']['Quantité'];
				}
				foreach ($etapes_print_info as $key => $value) {
					if($key === 'attributes') {
						foreach ($value as $k => $v) {
							$item_data[] = array(
								'key'   => $k,
								'value' => $v
							);
						}
					} else {
						$item_data[] = array(
							'key'   => $key,
							'value' => $value
						);
					}
				}
			}
		}
		return $item_data;	
	}

	public function custom_cart_item_name( $product_name, $cart_item, $cart_item_key ) {
		$options = $this->dataset->get_options();
		$product = $cart_item['data'];

		$product_name = '<div class="cart-item-details">';
		$product_name .= '<div class="cart-item-info">';
		$product_name .= '<h4 class="cart-item-title">' . ucfirst($product->get_title()) . '</h4>';
		
		$productCurrent = wc_get_product( $cart_item['product_id'] );
		$product_type = $productCurrent->get_type();

		$display = true;
		if(isset($cart_item['etapes_print']) AND $display){	
			$product_name .= '<div class="cart-item-sub-info">';
			foreach ($cart_item['etapes_print'] as $key => $value) {
				if ($key == 'Quantité') {
					$product_name .= '<p class=cart-item-info-meta><b>' . $key . ' : </b> ' . $value . '</p>';
				}
			}
			$product_name .= '</div>';
		}

		if($product_type === 'variable'){	
			$product_name .= '<div class="cart-item-sub-info">';
			foreach ($cart_item['variation'] as $attribute_name => $attribute_value) {
				$attribute_value_str = str_replace('_',' ',$attribute_value);
				$attribute_name = str_replace(array('attribute_pa_', '_', '-'), array('', ' ', ' '), $attribute_name);
				$product_name .= '<p><b>' . ucfirst($attribute_name) . ' : </b> ' . $attribute_value_str . '</p>';
			}
			$product_name .= '</div>';
		}

		$product_name .= '</div>';
		$product_name .= '</div>';
		return $product_name;
	}

	public function add_custom_price( $cart_object ) {
		foreach ( $cart_object->get_cart() as $cart_item_key => $cart_item ){
			$productCurrent = wc_get_product( $cart_item['product_id'] );
			$product_type = $productCurrent->get_type();
			if ( isset($cart_item['etapes_print']) AND $product_type === 'etapes_print' ) {
				$cart_item['data']->set_price($cart_item['etapes_print']['price']);
			}
		}
	}

	public function checkout_create_order_line_item($item, $cart_item_key, $values, $order) {
		foreach ( $values['etapes_print'] as $key => $value) {
			if($key != 'price'){
				$item->add_meta_data($key, $value);
			}
		}
	}

	public function cart_item_quantity($product_quantity, $cart_item_key, $cart_item) {
		$product_id = $cart_item['product_id'];
    if ( isset( $cart_item['etapes_print_quantity'] ) ) {
        return $cart_item['etapes_print_quantity'];
    }
    return $product_quantity;
	}

	public function remove_cart_action( $cart_item_key, $cart ) {
		$removed_item = $cart->removed_cart_contents[ $cart_item_key ];

		if ( isset( $removed_item['etapes_print_pdf'] ) && isset( $removed_item['etapes_print_pdf'][0] ) &&
				isset( $removed_item['etapes_print_pdf'][0]['etapes_print_pdf_id'] ) && $removed_item['etapes_print_pdf'][0]['etapes_print_pdf_id'] !== '' ) {

			$etapes_print_pdf_id = $removed_item['etapes_print_pdf'][0]['etapes_print_pdf_id'];

			$delete_status = wp_delete_attachment( $etapes_print_pdf_id, true );
		}
	}

	public function before_calculate_totals( $cart ) {
		if ( is_admin() && ! defined( 'DOING_AJAX' ) )
				return;

		if ( did_action( 'woocommerce_before_calculate_totals' ) >= 2 )
				return;

		// First loop to check if product 11 is in cart
		foreach ( $cart->get_cart() as $cart_item_key => $cart_item ){
			
			if ( isset($cart_item['etapes_print_price']) && isset($cart_item['etapes_print_quantity'] ) ) {
				$cart->set_quantity( $cart_item_key, $cart_item['etapes_print_quantity'] );
				$cart_item['data']->set_price($cart_item['etapes_print_price'] / $cart_item['etapes_print_quantity']);
				// $cart_item['data']->set_price($cart_item['etapes_print_price']);
			}
		}
	}
	 

	public function is_sold_individually( $return, $product ) {
		return get_post_meta( get_the_ID(), 'etapes_print_quantity', true );
	}

	public function get_price_html( $price, $current_product ) {
		// global $product;
		$current_product_id = url_to_postid(home_url( $_SERVER['REQUEST_URI'] ));
		if ( 'etapes_print' == $current_product->get_type() ) {
			if (isset($_REQUEST['post_type'])) {
				$margin_value = get_post_meta( get_the_ID(), '_marge_beneficiaire', true );
				$margin_currency = get_post_meta( get_the_ID(), '_marge_beneficiaire_currency', true );
				$remise = get_option('etapes_print_remise_revendeur');
				return '<span class="ep_remise_html">' .esc_html( "-$remise") . '</span>&nbsp;<span class="ep_marge_html">' . esc_html( "+$margin_value{$margin_currency}" ) . '</span>';
			} else if (is_product() &&  $current_product->get_id() === $current_product_id) {
				$this->product_variations();
				return '';
			} else {
				return '<span class="ep_price_html woocommerce-Price-amount amount">A partir de ' . $price . '</span>';
			}
		} else if( $current_product->is_type( 'variable' ) && is_product() ) {
			$custom_field_value = get_field('produit_personnalise');
			if($custom_field_value){
				$this->product_variations();
				return '';
			}
		}
		return $price;
	}

    //Add variable product to cart
	public function add_product_to_cart_via_url() {
		$product_id = isset($_GET['add-to-cart']) ? absint($_GET['add-to-cart']) : '';
		$id_user = get_current_user_id();

		if($product_id){
			$productCurrent = wc_get_product( $product_id  );
			$product_type = $productCurrent->get_type();
		}
		
		if( isset($product_type) && $product_type === 'variable'){
			global $wpdb;
			$table_name = $wpdb->prefix . 'etapes_print_add_info_cart_item';
			$query = "SELECT * FROM $table_name WHERE id_product = '$product_id' AND id_user = '$id_user' ";
			$result =  $wpdb->get_row(  $query );
			$field_value = get_field('produit_personnalise', $product_id);
			$info_cart = unserialize($result->info_cart_item);
			if ($field_value && $result && $info_cart['_designer_file']) {
				$variation_id = $info_cart['variation_id'];
				$attributes = $info_cart['attributes'];
				$quantity = isset($_GET['quantity']) OR $_GET['quantity'] != 0 ? absint($_GET['quantity']) : 1;

				$product_type = get_post_type($product_id);
				
				WC()->cart->add_to_cart($product_id, $quantity, $variation_id, $attributes);
			
				return wc_get_cart_url();
			}
		} else if (isset($product_type) && $product_type === 'etapes_print'){
			return wc_get_cart_url();
		}

	}

	public function force_login_bypass($result) {
		if ( ! empty( $result ) ) {
			return $result;
		}
		if ( '/wp-json/etapes-print-client/status' === $_SERVER['REQUEST_URI'] ) {
			return true;
		}
		return $result;
	}

    //Add info cart/metadata to cart
	public function add_info_cart_item(){
		check_ajax_referer( 'my-ajax-nonce', 'security' );
		global $wpdb;
		$table_name = $wpdb->prefix . 'etapes_print_add_info_cart_item';
		$data = [ 
			'id_user' => $_POST['id_user'],
			'id_product' => $_POST['id_product'],
			'info_cart_item' => serialize($_POST['info_cart_item']),
		];
		$response = $wpdb->insert($table_name, $data);
		echo $response;
		wp_die();
	}

	//Return variation id
	public function get_variation_id_callback() {
		check_ajax_referer( 'my-ajax-nonce', 'security' );
		$product_id = absint( $_POST['product_id'] );
		$match_attributes = array_map( 'sanitize_text_field', $_POST['attributes'] );
		
		$variations_data = array();
		$variation_id = $this->find_matching_variation_id($product_id, $match_attributes);
		if ($variation_id != 0 ) {
			$variation = wc_get_product($variation_id);
			if ($variation) {
				$variations_data['variation_id'] = $variation_id;
				$variations_data['price'] = $variation->get_price();
				$variations_data['attributes'] = $variation->get_variation_attributes();
			}
		}
		echo json_encode($variations_data);
		wp_die();
	}
	
	//Get variation id by comparison product id and attributes
	public function find_matching_variation_id($product_id, $match_attributes) {
		$variation_id = 0;
		$product = wc_get_product($product_id);
		if ($product && $product->is_type('variable')) {
			$variations = $product->get_children();
			foreach ($variations as $variation_id_item) {
				$variation = wc_get_product($variation_id_item);
				if ($variation->get_variation_attributes() == $match_attributes) {
					$variation_id = $variation->get_id();
					break;
				}
			}
		}
		return $variation_id;
	}

	//notice_woocommerce_variable
	function notice_woocommerce_variable() {
		if(isset($_GET['add-to-cart'])){
			$productCurrent = wc_get_product( $_GET['add-to-cart'] );
			$product_type = $productCurrent->get_type();
			if($product_type === 'variable'){	
				echo <<<HTML
				<style> .woocommerce-error { display: none; } </style>
				HTML;
			}
		}
	}

	// Add_apply_point
	function add_apply_discount_button() {
		$cart = WC()->cart;
		$shipping_method_cost = $this->get_shipping_cost($cart);
		$customer_id = get_current_user_id();
		$total_points = get_user_meta( $customer_id, 'total_points', true );
		$pointDiscount = $cart->get_discount_total();
        global $wpdb ;
		$AvailablePoints = $wpdb->get_col( $wpdb->prepare( "SELECT SUM((earnedpoints-usedpoints)) FROM {$wpdb->prefix}rspointexpiry WHERE earnedpoints-usedpoints NOT IN(0) and expiredpoints IN(0) and userid = %d" , $customer_id) ) ;
		if ( ! srp_check_is_array( $AvailablePoints ) ) {
			return 0 ;
		}
		$Point = round(array_sum( $AvailablePoints ), 2);

		$point_checked = get_option($customer_id. '_point_checked');
		$redeemed_point_post = get_post_meta( $point_checked , 'coupon_amount_point' , true );
		$redeemed_point_post = $redeemed_point_post ? $redeemed_point_post : 0;
		$redeemed_point = wc_price( $redeemed_point_post );

		echo <<<HTML
			<tr class="tr_apply_coupon point_redeemed_market">
				<th>Points Optimarket échangés</th>
				<td>
					<span class="redeemed_points">-$redeemed_point</span>
					<input type="hidden" value={$redeemed_point_post} id="redeemed_point_post">
					<a href="?remove_coupon=sumo_takaoma" class="woocommerce-remove-coupon rsc" data-coupon="sumo_takaoma"></a>
				</td>
			</tr>
			<tr class="woocommerce-shipping-totals d-none">
				<th>
					<div class="ttlship">Livraison :  Etapes Print</div>
				</th>
				<td data-title="Livraison :  Etapes Print">
					<ul id="shipping_method" class="woocommerce-shipping-methods">
						<li>
							<input type="checkbox" name="pay_ship_with_point" data-index="0" id="pay_ship_with_point" value="" class="shipping_method">
							<label for="shipping_method_0_free_shipping1">Payer le frais de livraison avec mes points (-$shipping_method_cost €)</label>					
						</li>
					</ul>
				</td>
			</tr>
		HTML;
		return $Point;
	}

	// Change cart value in the chekout page
	function change_total_cart_value($total, $cart) {
		$shipping_method_cost = $this->get_shipping_cost($cart);
		$id_user = get_current_user_id();

		$shipping_method_cost = $this->get_shipping_cost($cart);
		$point = $cart->get_discount_total();
		$totalHT = $cart->get_subtotal();
	 	$TTC = $cart->get_totals()['subtotal_tax'];
		$totalTTC = $totalHT + $TTC + ( $shipping_method_cost ? $shipping_method_cost : 0 );

		$point_checked = get_option($id_user. '_point_checked');
		$redeemed_point = (float) get_post_meta( $point_checked , 'coupon_amount_point' , true ) ;

		$new_total = $totalTTC - ( $point ? $point : 0 );

		if ($redeemed_point) {
			$new_total = max($totalTTC - $redeemed_point, 0) ;
		} else if ($shipping_method_cost && isset($id_user)){
			if(is_cart()){
				echo "<input type='hidden' class='shipping_value' value=$shipping_method_cost>";
				update_option($id_user. '_point_checked', false);
			}
			if(is_checkout()){
				$point_checked = get_option($id_user. '_point_checked');
				if($point_checked){
					if($shipping_method_cost){
						$rounded_cost = round($shipping_method_cost, 2);
						$new_total = $totalTTC - $rounded_cost ; 
					}
				}
			}	
		}
		return $new_total;
  	}

	//Get total cart
	function get_total_cart(){
		$cart = WC()->cart;
		$totals = $cart->get_totals();
		$total = $totals['total'];
		$id_user = get_current_user_id();
		if (isset($_POST['isChecked'], $id_user)) {
			$isChecked = $_POST['isChecked'];
			update_option($id_user . '_point_checked', $isChecked === "true");
			$response = array(
				'checked' =>  $_POST['isChecked'],
				'success' => true,
				'message' => 'Option succes',
				'total' => $total
			);
			echo json_encode($response);
		}
		wp_die();
	}
	
	// Get shipping cost
	public function get_shipping_cost($cart){
		$shipping_methods = WC()->shipping()->get_packages()[0]['rates'];
		$shipping_method_cost = null;
		if ($cart->needs_shipping()) {
			$shipping_packages = $cart->get_shipping_packages();
			foreach ($shipping_packages as $shipping_package) {
			$chosen_methods = WC()->session->get('chosen_shipping_methods');
				foreach ($shipping_methods as $shipping_method) { 
					if ($shipping_method->get_method_id() === $chosen_methods[0]) { 
						$shipping_method_cost = $shipping_method->get_cost();
					}
				}
			}
		}
		return $shipping_method_cost;
	}

	// Hook before tax on cart/checkout page
	function custom_hook_before_tax_cart_page() {
		$cart = WC()->cart;
		$totals = (float) $cart->get_totals()['total'];
		$subtotal = (float) $cart->get_totals()['subtotal'];
		$shipping_total = (float) $cart->get_totals()['shipping_total'];
		$shipping_tax = (float) $cart->get_totals()['shipping_tax'];

		$id_user = get_current_user_id();
		$point_checked = get_option($id_user. '_point_checked');
		// $totalsht = $subtotal;
		// $totalshtround = wc_price( $totalsht );
		$subtotal_tax  = $cart->get_totals()['subtotal_tax'];
		$TTC = wc_price($subtotal_tax + $shipping_tax);
		$totalTTC_value = $subtotal_tax + $subtotal + $shipping_total + $shipping_tax;
		$totalTTC = wc_price($totalTTC_value);

		$point_checked = get_option($id_user. '_point_checked');
		$redeemed_point_get = get_post_meta( $point_checked , 'coupon_amount_point' , true );
		$redeemed_point = wc_price( min($redeemed_point_get, $totalTTC_value) );

		/* echo <<<HTML
			<tr class="tr_apply_coupon">
				<th>Total HT</th>
				<td style=color:var(--primary_color) id=totalshtround>$totalshtround</td>
			</tr>
			<tr class="tr_apply_coupon">
				<th>TVA</th>
				<td id=totalshtround>$TTC</td>
			</tr>
			<tr class="tr_apply_coupon order_total_ttc">
				<th>Total TTC</th>
				<td style=color:var(--primary_color) id=totalshtround>$totalTTC</td>
			</tr>
		HTML; */
		if($redeemed_point_get && is_checkout()){
			echo <<<HTML
				<tr class="tr_apply_coupon">
					<th>Points Optimarket échangés</th>
					<td id=totalshtround>
						<span>$redeemed_point_get (-$redeemed_point)</span>
						<input type="hidden" name="ep_redeemed_point" value="$redeemed_point_get"/>
					</td>
				</tr>
			HTML;
		}
	}

	// update_point_up : [Appliquer des points optimarket]
	function update_point_up() {
		$UserId = get_current_user_id();
		$UserInfo = get_user_by('id', $UserId);
		$UserName = $UserInfo->user_login;

		// reset coupon amount for current user
		$_point_checked_coupon_id = get_option($UserId . '_point_checked');
		if ($_point_checked_coupon_id) {
			delete_post_meta($_point_checked_coupon_id, 'coupon_amount_point');
		}

		$CouponData = array(
			'post_title'   => 'sumo_' . strtolower($UserName),
			'post_content' => '',
			'post_status'  => 'publish',
			'post_author'  => $UserId,
			'post_type'    => 'shop_coupon',
		);
		$CouponId = wp_insert_post($CouponData);
		if (isset($_POST['isCheckedTwo'])) {
			$cart = WC()->cart;
			$shipping_total = ceil($cart->get_totals()['shipping_total']);
			// Calculate Max Point - Plugin RewardSystem Fix
			$total_max_points = $shipping_total;
			$prod_items = WC()->cart->get_cart();
			foreach($prod_items as $item => $prod) {
				$_product =  wc_get_product( $prod['data']->get_id()); 
				$_product_id =  $_product->get_id();
				$_product_price = $_product->get_price();
				$_product_price_with_tax = $_product->get_price_including_tax($prod['quantity']);

				$available_points = 0;
				$point_percent = 100;

				$term = wp_get_post_terms($_product_id, 'classe-point');

				if ($_product->is_type('variation')) {
					$point_percent = 0;
					$_parent_id = $_product->get_parent_id();
					$term = wp_get_post_terms($_parent_id, 'classe-point');
				}

				if(!empty($term)){
					$classePointID = $term[0]->term_id;
					$point_percent = get_field('nb_point_max', 'classe-point_' . $classePointID ); // 20, 30, 40%
				}
				$available_points = round( $point_percent * $_product_price_with_tax  / 100 ); // si 100€ et 20% => 20 points
				$total_max_points += $available_points;
			}
			// END Calculate Max Point
			$redeemed_point_get = min($_POST['isCheckedTwo'], $total_max_points);
			update_post_meta($CouponId, 'coupon_amount_point', $redeemed_point_get);
			update_option($UserId . '_point_checked', $CouponId);
		}

	}
	
	//Remove point : [enlever]
	function remove_points() {
		if (isset($_POST['remove_coupons_all'])) {
			$customer_id = get_current_user_id();
			$point_checked = get_option($customer_id. '_point_checked', true);
			delete_post_meta($point_checked, 'coupon_amount_point');
			wp_send_json_success();
		} else {
			wp_send_json_error('Invalid request');
		}
		wp_die();
	}

	//Update point
	function update_point_used(){
		global $wpdb;
		$UserId = get_current_user_id() ;
		$redeemed_point_get = get_post_meta( $UserId , 'coupon_amount_point' , true );
		$iep_args = array(
			'usedpoints'     => $redeemed_point_get
		) ;
		$Up_rspointexpiry = $wpdb->update( "{$wpdb->prefix}rspointexpiry" , $iep_args, array( 'userid' => $UserId ) );
		wp_die();
	}

	//Save custom input to order meta during click button order : checkout page
	function save_custom_input_to_order_meta($order_id) {
		global $wpdb;
		if ($_POST['ep_redeemed_point']) {
			$UserId = get_current_user_id();
			$custom_input = sanitize_text_field($_POST['ep_redeemed_point']);
			update_post_meta($order_id, 'ep_redeemed_point', $custom_input);

			$_point_checked_coupon_id = get_option($UserId . '_point_checked');
			if ($_point_checked_coupon_id) {
				delete_post_meta($_point_checked_coupon_id, 'coupon_amount_point');
			}			
		}
	}

	//Add info cart/metadata to cart
	public function update_info_cart_item() {
		global $wpdb;
		$user_id = get_current_user_id();
		$table_name = $wpdb->prefix . 'etapes_print_add_info_cart_item';
		$response = array(); // JSON response array
		if (isset($_POST['id_product'], $_POST['download_url'])) {
			$product_id = $_POST['id_product'];
			$download_url = $_POST['download_url'];
			$query = $wpdb->prepare("SELECT * FROM $table_name WHERE id_product = %d AND id_user = %d", $product_id, $user_id);
			$result = $wpdb->get_row($query);
	
			// Prepare file information
			$upload_dir = wp_upload_dir();
			$upload_path = $upload_dir['basedir'];
			$folder_name = "designer";
			$dir = $upload_path . "/" . $folder_name;
	
			// Create the directory if it doesn't exist
			if (!file_exists($dir)) {
				mkdir($dir, 0755, true);
			}
	
			$file_url = parse_url($download_url);
			$file_name = basename($file_url['path']);
			$file_type = pathinfo($file_name, PATHINFO_EXTENSION);
			$ep_file_name = $product_id . '-' . $file_name;
			$file_path = wp_normalize_path($dir . '/' . $ep_file_name);
			$file_dir = site_url('wp-content/uploads') . '/designer/' . $ep_file_name;
			$file_content = file_get_contents($download_url);
	
			// Save the file using move_uploaded_file
			if ($file_content !== false && file_put_contents($file_path, $file_content) && file_exists($file_path)) {
				if ($result) {
					// Update the cart item information
					$info_cart_item = unserialize($result->info_cart_item);
					$info_cart_item['_designer_file'] = $file_dir;
					$data = [
						'info_cart_item' => serialize($info_cart_item),
					];
					$wpdb->update($table_name, $data, ['id_user' => $user_id]);
				} else {
					// Insert a new row
					$data = [
						'id_user' => $user_id,
						'id_product' => $product_id,
						'info_cart_item' => serialize(['_designer_file' => $file_dir]),
					];
					$wpdb->insert($table_name, $data);
				}
				// File successfully uploaded
				$response['success'] = true;
				$response['url'] = $file_path;
				$response['message'] = 'Fichier téléchargé avec succès.';
				wp_send_json_success($response);
			} else {
				// Error occurred while uploading the file or file doesn't exist
				$response['success'] = false;
				$response['url'] = $file_path;
				$response['message'] = 'Échec du téléchargement du fichier.';
				wp_send_json_error($response);
			}			
		} else {
			// Missing required parameters
			$response['success'] = false;
			$response['message'] = 'Missing parameters.';
			wp_send_json_error($response);
		}
		wp_die();
	}
	
	public function validate_product_add_to_cart($passed, $product_id, $quantity) {
		global $wpdb;
		$id_user = get_current_user_id();
		$field_value = get_field('produit_personnalise', $product_id);
		$table_name = $wpdb->prefix . 'etapes_print_add_info_cart_item';
		$query = "SELECT * FROM $table_name WHERE id_product = '$product_id' AND id_user = '$id_user' ";
		$result =  $wpdb->get_row(  $query );
		$data = unserialize($result->info_cart_item);
		if ($field_value && !$data['_designer_file']) {
			$passed = false; 
			$message = "Le produit n'a pas été ajouté au panier, veuillez vérifier si votre fichier a été ajouté correctement.";
			wc_add_notice($message, 'error');
			$wpdb->delete( $table_name, array( 'id_product' => $product_id, 'id_user' => $id_user ) );
		}
		return $passed;
	}

}
