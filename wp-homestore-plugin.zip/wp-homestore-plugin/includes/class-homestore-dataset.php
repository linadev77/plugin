<?php
/**
 * Fired during plugin activation
 *
 * @link       https://takamoastudio.com/
 * @since      1.0.0
 *
 * @package    homestore-takamoa
 * @subpackage homestore-takamoa/includes
 */

/**
 * Fired during plugin activation. https://regex101.com/r/TvKR9I/1
 *
 * This class defines all code necessary to run during the plugin"s activation.
 *
 * @since      1.0.0
 * @package    homestore-takamoa
 * @subpackage homestore-takamoa/includes
 * @author     Takamoa Studio <responsable@takamoastudio.com>
 */
class Homestore_Dataset {
    
}
?>