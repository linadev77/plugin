<?php
/**
 * Fired during plugin deactivation
 *
 * @link       https://takamoastudio.com/
 * @since      1.0.0
 *
 * @package    homestore-takamoa
 * @subpackage homestore-takamoa/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    homestore-takamoa
 * @subpackage homestore-takamoa/includes
 * @author     Takamoa Studio <responsable@takamoastudio.com>
 */
class Homestore_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {
	
	}

}
?>