<?php
/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       https://takamoastudio.com/
 * @since      1.0.0
 *
 * @package    homestore-takamoa
 * @subpackage homestore-takamoa/includes
 */
/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    homestore-takamoa
 * @subpackage homestore-takamoa/includes
 * @author     Takamoa Studio <responsable@takamoastudio.com>
 */
class Homestore {
	/**
	 * The loader that's responsible for maintaining and registering all hooks that power
	 * the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      Homestore_Loader    $loader    Maintains and registers all hooks for the plugin.
	 */
    protected $loader;

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $plugin_name    The string used to uniquely identify this plugin.
	 */
    protected $plugin_name;

	/**
	 * The current version of the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $version    The current version of the plugin.
	 */

    protected $version;

	/**
	 * DATASET
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      Homestore_Dataset    $dataset
	 */
	 
    protected $dataset;
	/**
	 * Define the core functionality of the plugin.
	 *
	 * Set the plugin name and the plugin version that can be used throughout the plugin.
	 * Load the dependencies, define the locale, and set the hooks for the admin area and
	 * the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */

	public function __construct() {
		if ( defined( 'HOMESTORE_VERSION' ) ) {
			$this->version = HOMESTORE_VERSION;
		} else {
			$this->version = '1.0.0';
		}

		$this->plugin_name = 'wp-homestore-plugin';
		$this->load_dependencies();
		$this->set_locale();

		$this->define_admin_hooks();
		$this->define_public_hooks();

	}

	/**
	 * Load the required dependencies for this plugin.
	 *
	 * Include the following files that make up the plugin:
	 *
	 * - Codebase_Loader. Orchestrates the hooks of the plugin.
	 * - Codebase_i18n. Defines internationalization functionality.
	 * - Codebase_Router. Defines studio routes.
	 * - Codebase_Admin. Defines all hooks for the admin area.
	 * - Codebase_Public. Defines all hooks for the public side of the site.
	 *
	 * Create an instance of the loader which will be used to register the hooks
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */

    private function load_dependencies() {
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-homestore-dataset.php';
		/**
		 * The class responsible for orchestrating the actions and filters of the
		 * core plugin.
		*/		
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-homestore-loader.php';
        
		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		*/
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-homestore-i18n.php';

		/**
		 * The class responsible for defining all actions that occur in the admin area.
		 */
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-homestore-admin.php';

		/**
		 * The class responsible for defining all actions that occur in the public-facing
		 * side of the site.
		 */		
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-homestore-public.php';

        $this->loader = new Homestore_Loader();
        $this->dataset = new Homestore_Dataset();
    }

	/**
	 * Define the locale for this plugin for internationalization.
	 *
	 * Uses the Codebase_i18n class in order to set the domain and to register the hook
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function set_locale() {

		$plugin_i18n = new Homestore_i18n();

		$this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );

	}

	/**
	 * Register all of the hooks related to the admin area functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	*/

	private function define_admin_hooks() {

		$plugin_admin = new Homestore_Admin( $this->get_plugin_name(), $this->get_version(), $this->get_dataset() );

		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles' );
		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts' );
		$this->loader->add_action( 'admin_menu', $plugin_admin, 'add_menu' );

		//get variation
		$this->loader->add_action('wp_ajax_get_variation_with_attribute',$plugin_admin, 'get_variation_with_attribute');
		$this->loader->add_action('wp_ajax_nopriv_get_variation_with_attribute',$plugin_admin, 'get_variation_with_attribute');		
		
		// mediatheque
		$this->loader->add_action('admin_enqueue_scripts',$plugin_admin, 'enqueue_wp_media');

		// add_variation_postmeta
		$this->loader->add_action('wp_ajax_add_variation_postmeta',$plugin_admin, 'add_variation_postmeta');
		$this->loader->add_action('wp_ajax_nopriv_add_variation_postmeta',$plugin_admin, 'add_variation_postmeta');
				
		// REST API : We may use it later but AJAX way is more secure
		// $this->loader->add_action( 'rest_api_init', $plugin_admin, 'init_admin_route' );

	}

	/**
	 * Register all of the hooks related to the public-facing functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */	
    private function define_public_hooks() {

		$plugin_public = new Homestore_Public( $this->get_plugin_name(), $this->get_version(), $this->get_dataset() );

		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_styles' );
		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_scripts' );

		$this->loader->add_action( 'woocommerce_before_single_variation', $plugin_public, 'product_variations', 15 );
		// $this->loader->add_action( 'woocommerce_after_single_product_summary', $plugin_public, 'product_variations', 15 );

	}

	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 *
	 * @since    1.0.0
	 */
	public function run() {
		$this->loader->run();
	}
    

	/**
	 * The name of the plugin used to uniquely identify it within the context of
	 * WordPress and to define internationalization functionality.
	 *
	 * @since     1.0.0
	 * @return    string    The name of the plugin.
	 */
	public function get_plugin_name() {
		return $this->plugin_name;
	}

	/**
	 * The reference to the class that orchestrates the hooks with the plugin.
	 *
	 * @since     1.0.0
	 * @return    Homestore_Loader    Orchestrates the hooks of the plugin.
	 */
	public function get_loader() {
		return $this->loader;
	}

	/**
	 * Retrieve the version number of the plugin.
	 *
	 * @since     1.0.0
	 * @return    string    The version number of the plugin.
	 */
	public function get_version() {
		return $this->version;
	}

	public function get_dataset() {
		return $this->dataset;
	}
}
?>