<div class="wrap">
    <h1>Personnalisation des Images d'Options d'Attributs</h1>
    <button id="add-icon-button" class="button">
        <span class="dashicons dashicons-plus"></span> Ajouter une Icône
    </button>
    <div class="wrap-content">
        <table class="wp-list-table widefat fixed striped table-view-list users" id="datatable" width="100%">
            <thead>
                <tr>
                    <th>Nom</th>
                    <th>Catégorie</th>
                    <th>Image</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($attributes as $attribute):
                    $terms = get_terms(
                        array(
                            'taxonomy' => 'pa_' . $attribute->attribute_name,
                            'hide_empty' => false,
                        )
                    ); foreach ($terms as $term):
                        $get_term = get_post_meta($term->term_id, 'url_icon', true);
                        if ($get_term):
                            ?>
                            <tr>
                                <td>
                                    <strong>
                                        <?php echo $term->name; ?>
                                    </strong>
                                </td>
                                <td>
                                    <?php echo $term->taxonomy; ?>
                                </td>
                                <td><img src="<?= $get_term ?>" alt="<?= $get_term ?>" width="70px"></td>
                                <td>
                                    <a href="<?= admin_url("admin.php?page=$page&id=$term->term_id&action=update&attribute=$term->taxonomy") ?>"
                                        class="btn_update">
                                        <span class="dashicons dashicons-edit"></span>
                                        <span>Modifier</span>
                                    </a>
                                    <a href="<?= admin_url("admin.php?page=$page&id=$term->term_id&action=delete") ?>"
                                        class="btn_delete">
                                        <span class="dashicons dashicons-trash"></span>
                                        <span>Effacer</span>
                                    </a>
                                </td>
                            </tr>
                            <?php
                        endif;
                    endforeach;
                endforeach;
                ?>
            </tbody>
        </table>

    </div>
    <!-- modal -->

    <div id="add-icon-modal" class="modal">
        <div class="modal-content">
            <div class="modal-content-header">
                <div class="form-group">
                    <label for="select-attribut">Sélectionner l'attribut :</label>
                    <?php
                    // Display the dropdown select with attributes
                    if (!empty($attributes)) {
                        echo '<select name="product_attributes" id="select-attribut"  class="select-attribut">';
                        echo '<option value="">Sélectionnez un attribut</option>';
                        foreach ($attributes as $attribute) {
                            echo '<option value="' . esc_attr('pa_' . $attribute->attribute_name) . '">' . esc_html($attribute->attribute_label) . '</option>';
                        }
                        echo '</select>';
                    } else {
                        echo 'No attributes found.';
                    }
                    ?>
                </div>

                <div class="form-group">
                    <label for="select-value">Sélectionner les valeurs :</label>
                    <select id="select-value" class="select-value">
                        <!-- <option>variations</option> -->
                    </select>
                </div>
                <div class="button-container">
                    <button id="save-button" class="button button-primary">Enregistrer</button>
                    <button id="cancel-button" class="button button-secondary">Annuler</button>
                </div>
            </div>

            <div class="modal-content-wrap">
                <div class="">
                    <h2>Ajouter une icône</h2>
                </div>
                <button type="button" id="upload-button" class="button button-secondary"><span class="dashicons dashicons-upload"></span>Télécharger une image</button>
                <?php
                if (isset($_GET['id'])) {
                    $meta = get_post_meta($_GET['id'], 'url_icon', true);
                } else {
                    $meta = '';
                }
                ?>
            </div>

            <div class="modal-content-footer">
                <img src="<?php echo $meta ?>" alt="<?php echo $meta ?>" id="preview-image"
                    style="max-width: 100%;width:100%;">
                <input type="hidden" name="uploaded_image_id" id="uploaded-image-id">
            </div>
        </div>
    </div>