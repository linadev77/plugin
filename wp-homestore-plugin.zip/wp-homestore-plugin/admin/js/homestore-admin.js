(function ($) {
	'use strict';

	/**
	 * All of the code for your admin-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */

	$(document).ready(function(){
		
		var modal = document.getElementById('add-icon-modal');
		var btn = document.getElementById('add-icon-button');
		var span = document.getElementById('cancel-button');
	
		btn.onclick = function() {
			modal.style.display = 'block';
		}

		
	
		span.onclick = function() {
			modal.style.display = 'none';
		}
	
		window.onclick = function(event) {
			if (event.target == modal) {
				modal.style.display = 'none';
			}
		}
		
		let variation_icon=$('#preview-image').attr('src');
		let variation_id = $('.select-value').val();
		let element2 = [];
		let newValue2 = [];
		let variation_icone2=[];		
		let table=$('#datatable');
		if(table.length){
			table.DataTable({
				language: {
					url: 'https://cdn.datatables.net/plug-ins/1.11.5/i18n/fr-FR.json',
				},
			});
		};		

		/****fetch all attributs with ajax***********************/

		$('.select-attribut').select2();

		$('.select-attribut').on('change', function() {

			const variation_icon=$('#preview-image').attr('src');
			const firstValue = $(this).val();	
			$.ajax({
				url: ajaxurl,
				type: 'POST',
				data: {
					action: 'get_variation_with_attribute',
					attribute_name: firstValue,
				},
				success: function(response) {
					$('.select-value').html(response);
					$('.select-value').empty();

					if(response){
						response.forEach((element,index) => {
							const selected = index === 0 ? 'selected' : '';							
							$('.select-value').append(`<option value="${element['term_id']}"  ${selected}>${element['name']}</option>`);	
							if( index === 0){
								callback_add(element['term_id'],variation_icon);
								element2 = element['term_id'];
								if(variation_icone2.length>0){
									disabled_button_add(element['term_id'],variation_icone2,false);
								}
							}
							
						});
					}
					
				}
			});

		});	


		/***fetch attributes***********/
		$('.select-value').on('change', function() {

			const selectedOption = $('.select-value option:selected');
			selectedOption.siblings().removeAttr('selected');
			selectedOption.attr('selected', 'selected');
			newValue2 = selectedOption.val();
			if(variation_icone2.length <= 0){
				variation_icone2 = null;
			}
			disabled_button_add(newValue2, variation_icone2, false);

		});
		
		
		/*******fileupload********************************/
		$('.modal-content-footer').css('width','0%');
		$('#upload-button').on('click', function() {

			var mediaUploader = wp.media({
				title: 'Select an Image',
				button: {
					text: 'Use this Image'
				},
				multiple: false // Set to true for multiple image selection
			});
	
			mediaUploader.on('select', function() {
				var attachment = mediaUploader.state().get('selection').first().toJSON();
				$('#preview-image').attr('src', attachment.url);
				$('#uploaded-image-id').val(attachment.id);
				variation_icon = $('#preview-image').attr('src');
				if (newValue2.length <= 0) {
					newValue2 = element2.length <= 0 ? null : element2;
				}
				variation_icone2 = variation_icon;
				$('.modal-content-footer').css('width','25%');
				disabled_button_add(newValue2, variation_icone2, false);
			});
	
			mediaUploader.open();

		});	

		/***disabled button add***/
		
		function disabled_button_add(variation_id,variation_icon,disabled){

			if((!variation_icon  || (!variation_id || variation_id === 'variations' || variation_id == 'undefined')) || disabled ){
				$('#save-button').attr('disabled','disabled');
			}else{
				$('#save-button').removeAttr('disabled');
			}
		}

		disabled_button_add(variation_id,variation_icon,true);

		/***add	************/
		$('#save-button').on('click',function(){

			const variation_id = $('.select-value').val();
			const variation_icon=$('#preview-image').attr('src');
			callback_add(variation_id,variation_icon);
			
			// Get the current URL
			var url = new URL(window.location.href);
			// Remove the 'action' parameter
			url.searchParams.delete('action');
			// Redirect to the new URL
			window.location.href = url.href;

		});

		function callback_add(variation_id,variation_icon){

			$.ajax({
				url: ajaxurl,
				type: 'POST',
				data: {
					action: 'add_variation_postmeta',
					variation_id: variation_id,
					variation_icon:variation_icon
				},
				success: function(response) {}
			});

		};

		function changeUpdate(params) {
			let url = new URL(window.location.href);
			let searchParams = new URLSearchParams(url.search);
		
			let idParam = searchParams.get('id');
			let actionParam = searchParams.get('action');
			let attributName = searchParams.get('attribute');

		
			if(actionParam=='update' && idParam && attributName){	
				modal.style.display = 'block';		
				$('#select-attribut').attr('disabled','disabled');
				$('#select-value').attr('disabled','disabled');
				$('.select-attribut').val(attributName);
				$('.select-attribut').trigger('change');
				
				// Surveiller les changements dans le DOM
				const observer = new MutationObserver(mutations => {
					$("#select-value option").removeAttr("selected");
					$(`#select-value option[value=${idParam}]`).attr("selected","selected");
				});
				const config = { childList: true, subtree: true };
				const targetNode = document.querySelector('#select-value');
				if (targetNode) {
					observer.observe(targetNode, config);
				}
			};
			
		}
		changeUpdate();


	})
	
})(jQuery);
