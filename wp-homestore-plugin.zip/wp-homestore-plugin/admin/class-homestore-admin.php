<?php
/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://takamoastudio.com/
 * @since      1.0.0
 *
 * @package    homestore-takamoa
 * @subpackage homestore-takamoa/admin
 */
global $wpdb;
/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    homestore-takamoa
 * @subpackage homestore-takamoa/admin
 * @author    Takamoa Studio <responsable@takamoastudio.com>
 */

class Homestore_Admin
{
	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	*/    
    private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */    
    private $version;
    
    private $dataset;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */    
    public function __construct($plugin_name, $version, $dataset)
    {

        $this->plugin_name = $plugin_name;
        $this->version = $version;
        $this->dataset = $dataset;
    }

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	*/    
    public function enqueue_styles()
    {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in Codebase_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The Codebase_Print_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */
        
        if ($this->plugin_name === 'wp-homestore-plugin') {

            wp_enqueue_style('datatable', 'https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css', array(),'', 'all');
            wp_enqueue_style('select2', 'https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css', array(), '4.0.13', 'all');

        }

        wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/homestore-admin.css', array(), $this->version, 'all');
    }

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */    
    public function enqueue_scripts()
    {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in Codebase_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The Codebase_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */

        if ($this->plugin_name === 'wp-homestore-plugin') {

            wp_enqueue_script('datatable', 'https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js', array(),'', true);
            wp_enqueue_script('select2', 'https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js', array('jquery'), '4.0.13', true);

        }

        wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'js/homestore-admin.js', array('jquery'), $this->version, false);
        wp_localize_script( $this->plugin_name, 'ajax_object', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );
    }

    public function add_menu()
    {        
        $icon_url = plugins_url( 'admin/image/icon.png', dirname(__FILE__) );        
        add_menu_page( 'Homestore', 'Homestore', 'manage_options', $this->plugin_name, array( $this, 'mon_contenu_de_page' ), $icon_url );

    }

    public function mon_contenu_de_page()
    {
        echo '<h1>Bienvenue dans le plugin !</h1>';
        // Get all product attributes
        $attributes = wc_get_attribute_taxonomies();
        $page = $_GET['page'];
        if (isset($_GET['id']) and isset($_GET['action'])) {
            if ($_GET['action'] == 'delete') {
                delete_post_meta($_GET['id'], 'url_icon');
            }
        }        
        include(plugin_dir_path(__FILE__) . 'partials/homestore-admin-display.php');
    }

    public  function get_variation_with_attribute(){
        $attribute=$_POST['attribute_name'];
        $terms = get_terms(array(
            'taxonomy' => $attribute,
            'hide_empty' => false,
        ));
        wp_send_json($terms);
    }
    function enqueue_wp_media() {
        wp_enqueue_media();
    }
    
    function add_variation_postmeta() {
        $variation_id = isset($_POST['variation_id']) ? intval($_POST['variation_id']) : 0;
        $variation_icon = isset($_POST['variation_icon']) ? sanitize_text_field($_POST['variation_icon']) : '';
        $response = array(
            'variation_id' => $variation_id,
            'variation_icon' => $variation_icon

        );        
    
        if ($variation_id > 0 && !empty($variation_icon)) {
                update_post_meta($variation_id, 'url_icon', $variation_icon);
                $response['success'] = true;
                $response['message'] = 'Variation postmeta updated successfully.';
            
        } else {
            $response['success'] = false;
            $response['message'] = 'Invalid variation ID or icon.';
        }
    
        wp_send_json($response);
    }
    
    
}
