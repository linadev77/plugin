<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://takamoastudio.com/
 * @since      1.0.0
 *
 * @package    homestore-takamoa
 * @subpackage homestore-takamoa/public
 */
?>
<h3 class="homestore_customization_title">Configurer votre produit :</h3>
<div id="homestore_product_customization" v-cloak>
    <table class="homestore_variations" cellspacing="0">
        <tbody>
            <tr v-for="attribute in formattedAttributes" :key="attribute.name">
                <th class="label">
                    <label :for="'homestore_' + attribute.name">{{ attribute.label }}</label>
                </th>
                <td class="value">
                    <div class="homestore_custom_field">
                        <div v-for="option in attribute.values" 
                            class="homestore_custom_field_option"
                            :class="{ active: selectedVariations[attribute.name] === option }"
                            :data-key="attribute.name"
                            :data-value="option.value"
                            @click.stop="setAttributeOption(attribute.name, option)"
                        >
                            <img class="lazyloaded" :src="option.image" :alt="option.name">
                            <p>{{ option.label }}</p>
                        </div>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
    <div class="variation_recap">
        <div ref="recap" class="recap-container">
            <h2 class="recap-title">Récapitulatif de votre commande</h2>
            <div  v-for="attribute in formattedAttributes" :key="attribute.name" class="order-recap">
                <div class="order-recap-item">
                    <p class="attributeName">{{ attribute.label }} :<p><p v-if="selectedVariations[attribute.name]">{{ selectedVariations[attribute.name].label }}</p>
                </div>
            </div>
            <div class="order-recap">
                <div class="order-recap-item">
                    <p class="current_price">Prix :</p>
                    <p>{{ formatPrice(current_price) }}</p>
                </div>   
            </div>
            <hr style="0.3px solid rgba(143, 143, 143,0.3)">
            <div class="order-recap-item total" style="color:#006FB7;">
                <div class="title" >TOTAL TTC</div>
                <div class="value">{{ formatPrice(current_price) }}</div>
            </div>
            <?php $id = get_the_ID();?>
            <div class="homestore_add_to_cart">
                <button ref="addToCart" type="submit" name="add-to-cart" class="single_add_to_cart_button button custom_button" value="<?php echo $id; ?>">
                Terminer
                </button>
            </div>
        </div>
    </div>
</div>
