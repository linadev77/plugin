<?php
/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://takamoastudio.com/
 * @since      1.0.0
 *
 * @package    homestore-takamoa
 * @subpackage homestore-takamoa/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    homestore-takamoa
 * @subpackage homestore-takamoa/public
 * @author     Takamoa Studio <responsable@takamoastudio.com>
 */
class Homestore_Public {
	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;	

	private $dataset;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */	
	public function __construct( $plugin_name, $version, $dataset ) {
		require_once ABSPATH . 'wp-admin/includes/image.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';

		$this->plugin_name = $plugin_name;
		$this->version = $version;
		$this->dataset = $dataset;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */	
	public function enqueue_styles() {
		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/homestore-public.css', array(), $this->version, 'all' );
	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {
		if ( is_product() ) {
			// Get the product ID
			$product_id = get_the_ID();

			// Get the product object
			$product = wc_get_product( $product_id );
			if ( $product->is_type( 'variable' ) ) {
				// Switch to vue.global.prod.min.js on Production!
				// wp_enqueue_script('vue', 'https://cdnjs.cloudflare.com/ajax/libs/vue/3.3.0-alpha.4/vue.global.prod.min.js', [], '1', true);
				wp_enqueue_script('vue', 'https://unpkg.com/vue@3', [], '3', true);
				
				$variation_attributes = $product->get_variation_attributes();
				$formatted_attributes = $this->get_formatted_attributes($variation_attributes);

				wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/homestore-public.js', array( 'jquery' ), $this->version, false );
				wp_localize_script( $this->plugin_name, 'product_formatted_attributes', $formatted_attributes);
			}
		}
	}

	public function product_variations() {
		global $product;
    	if ($product->is_type('variable')) {
			include( plugin_dir_path( __FILE__ ) . 'partials/homestore-public-display.php' );
		}
	}
	
	public function get_formatted_attributes($attributes) {
		$formatted_attributes = array();

		foreach ($attributes as $attribute_key => $attribute_values) {
			$attribute_name = wc_attribute_label($attribute_key); // This will get you the human-readable name

			$formatted_attribute = array(
				'label' => $attribute_name,
				'name'  => 'attribute_' . sanitize_title($attribute_key),
				'values' => array()
			);
			$url_image_default=plugin_dir_url(dirname(__FILE__)) . 'public/images/placeholder.png';
			if (strpos($attribute_key, 'pa_') === 0) { // It's a global attribute
				foreach ($attribute_values as $term_slug) {
					$term = get_term_by('slug', $term_slug, $attribute_key);
					if ($term && !is_wp_error($term)) {
						$url_image=get_post_meta($term->term_id, 'url_icon', true);
						if(!$url_image){
							$url_image=$url_image_default;
						}											
						$formatted_attribute['values'][] = array(
							'label' => $term->name,
							'name' => $term->slug,
							'value' => $term->slug,
							'id' => $term->term_id,
							'image' => $url_image
						);
					}
				}
			} else { // It's a custom attribute
				foreach ($attribute_values as $attribute_value) {
					$formatted_attribute['values'][] = array(
						'label' => $attribute_value,
						'name' => sanitize_title($attribute_value),
						'value' => $attribute_value
					);
				}
			}

			// Add none value
			$formatted_attribute['values'][] = array(
				'label' => 'Choisir une option',
				'name' => 'without-option',
				'value' => '',				
				'image'=>$url_image_default
			);

			$formatted_attributes[] = $formatted_attribute;
		}

		return $formatted_attributes;
	}
}
?>