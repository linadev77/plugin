(function ($) {
  'use strict';
  $(document).ready(function () {
    if (typeof product_formatted_attributes !== 'undefined') {
      const { createApp } = Vue;
      createApp({
        data() {
          return {
            recapElement: null,
            parentElement: null,
            formattedAttributes: product_formatted_attributes,
            current_price: 0,
            selectedVariations: {}
          };
        },
        methods: {
          setAttributeOption(name, option) {
            const selectElement = document.querySelector(`select[name="${name}"]`);
            const optionToSelect = selectElement.querySelector(`option[value="${option.value}"]`);

            if (optionToSelect) {
              selectElement.value = option.value;
              const changeEvent = new Event('change', {
                bubbles: true,
                cancelable: true,
              });
              selectElement.dispatchEvent(changeEvent);
              this.updateAvailableOption();
              this.selectedVariations[name] = option;
            } else {
              console.log(`Value "${option.value}" is not a valid option.`);
            }
          },
          updateAvailableOption() {
            this.formattedAttributes.forEach(attribute => {
              const selectElement = document.querySelector(`select[name="${attribute.name}"]`);
              const customFieldOptions = document.querySelectorAll(`.homestore_custom_field_option[data-key="${attribute.name}"]`);

              customFieldOptions.forEach(option => {
                const optionValue = option.getAttribute('data-value');
                const optionExists = Array.from(selectElement.options).some(option => option.value === optionValue);

                if (!optionExists) {
                  option.classList.add('disabled');
                } else {
                  option.classList.remove('disabled');
                }
              });
            });
          },
          fetchPrice() {
            let totalPrice = 0;

            const variationPriceElement = document.querySelector(".woocommerce-variation-price .price .woocommerce-Price-amount bdi");
            if (variationPriceElement) {
              const priceText = variationPriceElement.textContent.trim();
              const priceValue = parseFloat(priceText.replace(/[^0-9.-]+/g, ""));
              totalPrice = priceValue;

            } else {
              console.log("variationPriceElement introuvable.");
            }
            this.current_price = totalPrice;
          },
          formatPrice(price) {
            if (typeof price !== 'number') {
              return price;
            }
            let formatted = price.toFixed(2);
            formatted = formatted.replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
            return formatted + ' Ar';
          },
          handleScroll(event) {
            const current = this.parentElement.getBoundingClientRect().top;
            const parentHeight = this.parentElement.offsetHeight;
            const recapHeight = this.recapElement.offsetHeight;
            const margin = 200;
            if (current < margin) {
              let marginTop = margin - current;
              marginTop = Math.min(marginTop, parentHeight - recapHeight)
              $(this.recapElement).css('margin-top', marginTop);
            }
          },
        },
        mounted() {
          this.recapElement = this.$refs.recap;
          this.parentElement = this.recapElement.parentElement;
          window.addEventListener('scroll', this.handleScroll);

          this.formattedAttributes.forEach(attribute => {
            const selectElement = document.querySelector(`select[name="${attribute.name}"]`);
            if (selectElement) {
              const selectedValue = selectElement.value;
              const option = attribute.values.find(option => option.value === selectedValue);
              this.selectedVariations[attribute.name] = option;
            }
          });

          // Surveiller les changements dans le DOM
          const observer = new MutationObserver(mutations => {
            this.fetchPrice();
            this.updateAvailableOption();
          });
          const config = { childList: true, subtree: true };
          const targetNode = document.querySelector('.woocommerce-variation.single_variation');
          if (targetNode) {
            observer.observe(targetNode, config);
          }
        },
      }).mount("#homestore_product_customization");
    }
  });

})(jQuery);
