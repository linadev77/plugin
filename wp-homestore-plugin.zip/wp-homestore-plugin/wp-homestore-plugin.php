<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://takamoastudio.com/
 * @since             1.0.0
 * @package           homestore-takamoa
 *
 * @wordpress-plugin
 * Plugin Name:       Homestore Takamoa
 * Plugin URI:        https://takamoastudio.com
 * Description:       Special plugin for Homestore by Unik website.
 * Version:           1.0.0
 * Author:            Takamoa Studio
 * Author URI:        https://takamoastudio.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       Homestore
 * Domain Path:       /languages
 */
// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}
/**
 * Currently plugin version.
 * Start at version 0.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'homestore', '1.0.0' );
/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-homestore-activator.php
 */
function activate_homestore() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-homestore-activator.php';
	Homestore_Activator::activate();
}
/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-homestore-deactivator.php
 */
function deactivate_homestore() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-homestore-deactivator.php';
	Homestore_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_homestore' );
register_deactivation_hook( __FILE__, 'deactivate_homestore' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-homestore.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_homestore_by_unik() {
	$plugin = new Homestore();
	$plugin->run();
}

$plugin_path = trailingslashit( WP_PLUGIN_DIR ) . 'woocommerce/woocommerce.php';
if (in_array( $plugin_path, wp_get_active_and_valid_plugins() ) || in_array( $plugin_path, wp_get_active_network_plugins() )) {
	add_action( 'woocommerce_init', 'run_homestore_by_unik');
}

?>